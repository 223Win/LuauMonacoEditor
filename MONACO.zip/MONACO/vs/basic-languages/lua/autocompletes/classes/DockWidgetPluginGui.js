define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"HostWidgetWasRestored":{"label":{"name":"HostWidgetWasRestored","type":"(bool)"}}},"Event":[],"Method":{"RequestRaise":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/DockWidgetPluginGui/RequestRaise)"]},"insertText":"RequestRaise() \n\t\nend","label":{"name":"RequestRaise","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"IsFinished":{"label":{"name":"IsFinished","type":"(bool)"}}},"Event":[],"Method":{"AdvanceToNextPageAsync":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Pages/AdvanceToNextPageAsync)"]},"insertText":"AdvanceToNextPageAsync() \n\t\nend","label":{"name":"AdvanceToNextPageAsync","type":"(Function)"}},"GetCurrentPage":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Pages/GetCurrentPage)"]},"insertText":"GetCurrentPage() \n\t\nend","label":{"name":"GetCurrentPage","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Enabled":{"label":{"name":"Enabled","type":"(bool)"}},"RemoveOnHit":{"label":{"name":"RemoveOnHit","type":"(bool)"}},"Script":{"label":{"name":"Script","type":"(string)"}},"ContinueExecution":{"label":{"name":"ContinueExecution","type":"(bool)"}},"Id":{"label":{"name":"Id","type":"(int)"}},"Condition":{"label":{"name":"Condition","type":"(string)"}},"Line":{"label":{"name":"Line","type":"(int)"}},"LogMessage":{"label":{"name":"LogMessage","type":"(string)"}},"Verified":{"label":{"name":"Verified","type":"(bool)"}},"MetaBreakpointId":{"label":{"name":"MetaBreakpointId","type":"(int)"}},"Valid":{"label":{"name":"Valid","type":"(bool)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"MaxAxesForce":{"label":{"name":"MaxAxesForce","type":"(Vector3)"}},"MaxForce":{"label":{"name":"MaxForce","type":"(float)"}},"MaxVelocity":{"label":{"name":"MaxVelocity","type":"(float)"}},"RigidityEnabled":{"label":{"name":"RigidityEnabled","type":"(bool)"}},"Responsiveness":{"label":{"name":"Responsiveness","type":"(float)"}},"ForceLimitMode":{"label":{"name":"ForceLimitMode","type":"(ForceLimitMode)"}},"Position":{"label":{"name":"Position","type":"(Vector3)"}},"ApplyAtCenterOfMass":{"label":{"name":"ApplyAtCenterOfMass","type":"(bool)"}},"Mode":{"label":{"name":"Mode","type":"(PositionAlignmentMode)"}},"ReactionForceEnabled":{"label":{"name":"ReactionForceEnabled","type":"(bool)"}},"ForceRelativeTo":{"label":{"name":"ForceRelativeTo","type":"(ActuatorRelativeTo)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
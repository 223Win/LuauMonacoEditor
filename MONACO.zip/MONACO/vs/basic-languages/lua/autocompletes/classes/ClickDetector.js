define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"MaxActivationDistance":{"label":{"name":"MaxActivationDistance","type":"(float)"}},"CursorIcon":{"label":{"name":"CursorIcon","type":"(Content)"}}},"Event":{"MouseHoverLeave":{"label":{"name":"MouseHoverLeave","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ClickDetector/MouseHoverLeave)"]}},"MouseHoverEnter":{"label":{"name":"MouseHoverEnter","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ClickDetector/MouseHoverEnter)"]}},"mouseClick":{"label":{"name":"mouseClick","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ClickDetector/mouseClick)"]}},"MouseClick":{"label":{"name":"MouseClick","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ClickDetector/MouseClick)"]}},"MouseActionReplicated":{"label":{"name":"MouseActionReplicated","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ClickDetector/MouseActionReplicated)"]}},"RightMouseClick":{"label":{"name":"RightMouseClick","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ClickDetector/RightMouseClick)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
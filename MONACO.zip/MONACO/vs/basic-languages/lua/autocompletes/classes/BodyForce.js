define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"force":{"label":{"name":"force","type":"(Vector3)"}},"Force":{"label":{"name":"Force","type":"(Vector3)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
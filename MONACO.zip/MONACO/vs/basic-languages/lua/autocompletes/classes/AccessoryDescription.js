define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"AssetId":{"label":{"name":"AssetId","type":"(int64)"}},"Order":{"label":{"name":"Order","type":"(int)"}},"Instance":{"label":{"name":"Instance","type":"(Instance)"}},"IsLayered":{"label":{"name":"IsLayered","type":"(bool)"}},"Puffiness":{"label":{"name":"Puffiness","type":"(float)"}},"AccessoryType":{"label":{"name":"AccessoryType","type":"(AccessoryType)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
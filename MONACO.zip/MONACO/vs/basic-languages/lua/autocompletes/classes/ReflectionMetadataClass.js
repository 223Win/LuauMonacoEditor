define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Insertable":{"label":{"name":"Insertable","type":"(bool)"}},"ExplorerImageIndex":{"label":{"name":"ExplorerImageIndex","type":"(int)"}},"PreferredParent":{"label":{"name":"PreferredParent","type":"(string)"}},"ExplorerOrder":{"label":{"name":"ExplorerOrder","type":"(int)"}},"ServiceVisibility":{"label":{"name":"ServiceVisibility","type":"(ServiceVisibility)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
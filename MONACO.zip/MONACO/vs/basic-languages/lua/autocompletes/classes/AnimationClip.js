define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Priority":{"label":{"name":"Priority","type":"(AnimationPriority)"}},"Loop":{"label":{"name":"Loop","type":"(bool)"}},"GuidBinaryString":{"label":{"name":"GuidBinaryString","type":"(BinaryString)"}},"Guid":{"label":{"name":"Guid","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
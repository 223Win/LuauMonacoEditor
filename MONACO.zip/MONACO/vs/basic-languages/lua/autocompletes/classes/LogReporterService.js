define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"ReportLog":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/LogReporterService/ReportLog)"]},"insertText":"ReportLog(${1:logId}, ${2:desc}) \n\t\nend","label":{"name":"ReportLog","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
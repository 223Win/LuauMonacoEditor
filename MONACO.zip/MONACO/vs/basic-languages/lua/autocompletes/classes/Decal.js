define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Transparency":{"label":{"name":"Transparency","type":"(float)"}},"Color3":{"label":{"name":"Color3","type":"(Color3)"}},"LocalTransparencyModifier":{"label":{"name":"LocalTransparencyModifier","type":"(float)"}},"Shiny":{"label":{"name":"Shiny","type":"(float)"}},"ZIndex":{"label":{"name":"ZIndex","type":"(int)"}},"Specular":{"label":{"name":"Specular","type":"(float)"}},"Texture":{"label":{"name":"Texture","type":"(Content)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
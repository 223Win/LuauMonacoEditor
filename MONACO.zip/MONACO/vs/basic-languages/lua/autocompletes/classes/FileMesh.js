define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"TextureId":{"label":{"name":"TextureId","type":"(Content)"}},"MeshId":{"label":{"name":"MeshId","type":"(Content)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
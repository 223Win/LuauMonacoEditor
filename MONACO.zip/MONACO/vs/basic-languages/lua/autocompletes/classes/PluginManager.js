define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"CreatePlugin":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PluginManager/CreatePlugin)"]},"insertText":"CreatePlugin() \n\t\nend","label":{"name":"CreatePlugin","type":"(Function)"}},"ExportPlace":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PluginManager/ExportPlace)"]},"insertText":"ExportPlace(${1:filePath}) \n\t\nend","label":{"name":"ExportPlace","type":"(Function)"}},"ExportSelection":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PluginManager/ExportSelection)"]},"insertText":"ExportSelection(${1:filePath}) \n\t\nend","label":{"name":"ExportSelection","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
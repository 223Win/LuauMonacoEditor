define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"FillColor":{"label":{"name":"FillColor","type":"(Color3)"}},"OutlineTransparency":{"label":{"name":"OutlineTransparency","type":"(float)"}},"LineThickness":{"label":{"name":"LineThickness","type":"(int)"}},"Adornee":{"label":{"name":"Adornee","type":"(Instance)"}},"FillTransparency":{"label":{"name":"FillTransparency","type":"(float)"}},"OutlineColor":{"label":{"name":"OutlineColor","type":"(Color3)"}},"Enabled":{"label":{"name":"Enabled","type":"(bool)"}},"ReservedId":{"label":{"name":"ReservedId","type":"(ReservedHighlightId)"}},"DepthMode":{"label":{"name":"DepthMode","type":"(HighlightDepthMode)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
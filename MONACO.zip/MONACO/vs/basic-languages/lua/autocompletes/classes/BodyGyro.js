define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"P":{"label":{"name":"P","type":"(float)"}},"MaxTorque":{"label":{"name":"MaxTorque","type":"(Vector3)"}},"maxTorque":{"label":{"name":"maxTorque","type":"(Vector3)"}},"D":{"label":{"name":"D","type":"(float)"}},"cframe":{"label":{"name":"cframe","type":"(CFrame)"}},"CFrame":{"label":{"name":"CFrame","type":"(CFrame)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
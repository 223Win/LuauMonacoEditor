define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"ReactionTorqueEnabled":{"label":{"name":"ReactionTorqueEnabled","type":"(bool)"}},"RelativeTo":{"label":{"name":"RelativeTo","type":"(ActuatorRelativeTo)"}},"AngularVelocity":{"label":{"name":"AngularVelocity","type":"(Vector3)"}},"MaxTorque":{"label":{"name":"MaxTorque","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
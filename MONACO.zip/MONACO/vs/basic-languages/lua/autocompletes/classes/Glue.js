define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"F0":{"label":{"name":"F0","type":"(Vector3)"}},"F1":{"label":{"name":"F1","type":"(Vector3)"}},"F2":{"label":{"name":"F2","type":"(Vector3)"}},"F3":{"label":{"name":"F3","type":"(Vector3)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
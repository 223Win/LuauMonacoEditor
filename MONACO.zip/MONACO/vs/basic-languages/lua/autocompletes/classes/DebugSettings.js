define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"RobloxVersion":{"label":{"name":"RobloxVersion","type":"(string)"}},"IsScriptStackTracingEnabled":{"label":{"name":"IsScriptStackTracingEnabled","type":"(bool)"}},"PlayerCount":{"label":{"name":"PlayerCount","type":"(int)"}},"ReportSoundWarnings":{"label":{"name":"ReportSoundWarnings","type":"(bool)"}},"TickCountPreciseOverride":{"label":{"name":"TickCountPreciseOverride","type":"(TickCountSampleMethod)"}},"JobCount":{"label":{"name":"JobCount","type":"(int)"}},"InstanceCount":{"label":{"name":"InstanceCount","type":"(int)"}},"DataModel":{"label":{"name":"DataModel","type":"(int)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
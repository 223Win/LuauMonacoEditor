define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"PantsTemplate":{"label":{"name":"PantsTemplate","type":"(Content)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
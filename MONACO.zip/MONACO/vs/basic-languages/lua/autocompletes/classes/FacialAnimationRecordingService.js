define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"BiometricDataConsent":{"label":{"name":"BiometricDataConsent","type":"(bool)"}}},"Event":[],"Method":{"IsAgeRestricted":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/FacialAnimationRecordingService/IsAgeRestricted)"]},"insertText":"IsAgeRestricted() \n\t\nend","label":{"name":"IsAgeRestricted","type":"(Function)"}},"CheckOrRequestCameraPermission":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/FacialAnimationRecordingService/CheckOrRequestCameraPermission)"]},"insertText":"CheckOrRequestCameraPermission() \n\t\nend","label":{"name":"CheckOrRequestCameraPermission","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
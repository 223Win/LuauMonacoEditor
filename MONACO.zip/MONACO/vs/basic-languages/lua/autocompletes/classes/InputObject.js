define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"UserInputType":{"label":{"name":"UserInputType","type":"(UserInputType)"}},"KeyCode":{"label":{"name":"KeyCode","type":"(KeyCode)"}},"Position":{"label":{"name":"Position","type":"(Vector3)"}},"Delta":{"label":{"name":"Delta","type":"(Vector3)"}},"UserInputState":{"label":{"name":"UserInputState","type":"(UserInputState)"}}},"Event":[],"Method":{"IsModifierKeyDown":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/InputObject/IsModifierKeyDown)"]},"insertText":"IsModifierKeyDown(${1:modifierKey}) \n\t\nend","label":{"name":"IsModifierKeyDown","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"GetPluginPolicy":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PluginPolicyService/GetPluginPolicy)"]},"insertText":"GetPluginPolicy(${1:pluginName}) \n\t\nend","label":{"name":"GetPluginPolicy","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
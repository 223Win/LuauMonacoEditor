define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Feedback":{"label":{"name":"Feedback","type":"(float)"}},"DryLevel":{"label":{"name":"DryLevel","type":"(float)"}},"WetLevel":{"label":{"name":"WetLevel","type":"(float)"}},"DelayTime":{"label":{"name":"DelayTime","type":"(float)"}}},"Event":[],"Method":{"GetConnectedWires":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AudioEcho/GetConnectedWires)"]},"insertText":"GetConnectedWires(${1:pin}) \n\t\nend","label":{"name":"GetConnectedWires","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Pivot Offset":{"label":{"name":"Pivot Offset","type":"(CFrame)"}},"Origin":{"label":{"name":"Origin","type":"(CFrame)"}}},"Event":[],"Method":{"GetPivot":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PVInstance/GetPivot)"]},"insertText":"GetPivot() \n\t\nend","label":{"name":"GetPivot","type":"(Function)"}},"PivotTo":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PVInstance/PivotTo)"]},"insertText":"PivotTo(${1:targetCFrame}) \n\t\nend","label":{"name":"PivotTo","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
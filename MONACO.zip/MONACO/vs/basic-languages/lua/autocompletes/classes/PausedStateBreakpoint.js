define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Breakpoint":{"label":{"name":"Breakpoint","type":"(Breakpoint)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
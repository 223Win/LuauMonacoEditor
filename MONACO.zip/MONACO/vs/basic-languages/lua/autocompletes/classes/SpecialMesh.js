define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"MeshType":{"label":{"name":"MeshType","type":"(MeshType)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
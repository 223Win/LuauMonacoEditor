define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"DraggerCoordinateSpace":{"label":{"name":"DraggerCoordinateSpace","type":"(DraggerCoordinateSpace)"}},"AnimateHover":{"label":{"name":"AnimateHover","type":"(bool)"}},"GeometrySnapColor":{"label":{"name":"GeometrySnapColor","type":"(Color3)"}},"AngleSnapEnabled":{"label":{"name":"AngleSnapEnabled","type":"(bool)"}},"HoverLineThickness":{"label":{"name":"HoverLineThickness","type":"(int)"}},"ShowPivotIndicator":{"label":{"name":"ShowPivotIndicator","type":"(bool)"}},"AngleSnapIncrement":{"label":{"name":"AngleSnapIncrement","type":"(float)"}},"JointsEnabled":{"label":{"name":"JointsEnabled","type":"(bool)"}},"AlignDraggedObjects":{"label":{"name":"AlignDraggedObjects","type":"(bool)"}},"ShowHover":{"label":{"name":"ShowHover","type":"(bool)"}},"LinearSnapEnabled":{"label":{"name":"LinearSnapEnabled","type":"(bool)"}},"HoverThickness":{"label":{"name":"HoverThickness","type":"(float)"}},"PivotSnapToGeometry":{"label":{"name":"PivotSnapToGeometry","type":"(bool)"}},"DraggerMovementMode":{"label":{"name":"DraggerMovementMode","type":"(DraggerMovementMode)"}},"CollisionsEnabled":{"label":{"name":"CollisionsEnabled","type":"(bool)"}},"LinearSnapIncrement":{"label":{"name":"LinearSnapIncrement","type":"(float)"}},"HoverAnimateFrequency":{"label":{"name":"HoverAnimateFrequency","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Width":{"label":{"name":"Width","type":"(float)"}},"Font":{"label":{"name":"Font","type":"(Font)"}},"Text":{"label":{"name":"Text","type":"(string)"}},"Size":{"label":{"name":"Size","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
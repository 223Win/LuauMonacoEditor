define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"SetAutoUpdate":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PluginManagementService/SetAutoUpdate)"]},"insertText":"SetAutoUpdate(${1:pluginId}, ${2:state}) \n\t\nend","label":{"name":"SetAutoUpdate","type":"(Function)"}},"GetOTAPluginVersion":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PluginManagementService/GetOTAPluginVersion)"]},"insertText":"GetOTAPluginVersion(${1:pluginName}) \n\t\nend","label":{"name":"GetOTAPluginVersion","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
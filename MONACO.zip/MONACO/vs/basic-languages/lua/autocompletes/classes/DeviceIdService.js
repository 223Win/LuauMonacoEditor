define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"GetDeviceId":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/DeviceIdService/GetDeviceId)"]},"insertText":"GetDeviceId() \n\t\nend","label":{"name":"GetDeviceId","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
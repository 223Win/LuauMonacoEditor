define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Enabled":{"label":{"name":"Enabled","type":"(bool)"}},"Path":{"label":{"name":"Path","type":"(string)"}},"Target":{"label":{"name":"Target","type":"(Instance)"}},"AutoSync":{"label":{"name":"AutoSync","type":"(bool)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
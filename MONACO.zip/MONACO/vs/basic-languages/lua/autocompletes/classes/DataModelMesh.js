define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Scale":{"label":{"name":"Scale","type":"(Vector3)"}},"VertexColor":{"label":{"name":"VertexColor","type":"(Vector3)"}},"Offset":{"label":{"name":"Offset","type":"(Vector3)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
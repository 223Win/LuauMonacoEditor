define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"MaskWeight":{"label":{"name":"MaskWeight","type":"(float)"}},"CFrame":{"label":{"name":"CFrame","type":"(CFrame)"}}},"Event":[],"Method":{"AddSubPose":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Pose/AddSubPose)"]},"insertText":"AddSubPose(${1:pose}) \n\t\nend","label":{"name":"AddSubPose","type":"(Function)"}},"RemoveSubPose":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Pose/RemoveSubPose)"]},"insertText":"RemoveSubPose(${1:pose}) \n\t\nend","label":{"name":"RemoveSubPose","type":"(Function)"}},"GetSubPoses":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Pose/GetSubPoses)"]},"insertText":"GetSubPoses() \n\t\nend","label":{"name":"GetSubPoses","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
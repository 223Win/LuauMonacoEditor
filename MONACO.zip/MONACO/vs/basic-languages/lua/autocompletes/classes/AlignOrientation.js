define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"LookAtPosition":{"label":{"name":"LookAtPosition","type":"(Vector3)"}},"MaxTorque":{"label":{"name":"MaxTorque","type":"(float)"}},"PrimaryAxis":{"label":{"name":"PrimaryAxis","type":"(Vector3)"}},"CFrame":{"label":{"name":"CFrame","type":"(CFrame)"}},"AlignType":{"label":{"name":"AlignType","type":"(AlignType)"}},"RigidityEnabled":{"label":{"name":"RigidityEnabled","type":"(bool)"}},"SecondaryAxis":{"label":{"name":"SecondaryAxis","type":"(Vector3)"}},"Responsiveness":{"label":{"name":"Responsiveness","type":"(float)"}},"PrimaryAxisOnly":{"label":{"name":"PrimaryAxisOnly","type":"(bool)"}},"Mode":{"label":{"name":"Mode","type":"(OrientationAlignmentMode)"}},"ReactionTorqueEnabled":{"label":{"name":"ReactionTorqueEnabled","type":"(bool)"}},"MaxAngularVelocity":{"label":{"name":"MaxAngularVelocity","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Height":{"label":{"name":"Height","type":"(float)"}},"Angle":{"label":{"name":"Angle","type":"(float)"}},"Radius":{"label":{"name":"Radius","type":"(float)"}},"InnerRadius":{"label":{"name":"InnerRadius","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
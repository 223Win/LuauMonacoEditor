define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Size":{"label":{"name":"Size","type":"(Vector3)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
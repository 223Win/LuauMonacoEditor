define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"LimitsEnabled":{"label":{"name":"LimitsEnabled","type":"(bool)"}},"MotorMaxAcceleration":{"label":{"name":"MotorMaxAcceleration","type":"(float)"}},"Size":{"label":{"name":"Size","type":"(float)"}},"UpperLimit":{"label":{"name":"UpperLimit","type":"(float)"}},"Velocity":{"label":{"name":"Velocity","type":"(float)"}},"LinearResponsiveness":{"label":{"name":"LinearResponsiveness","type":"(float)"}},"LowerLimit":{"label":{"name":"LowerLimit","type":"(float)"}},"CurrentPosition":{"label":{"name":"CurrentPosition","type":"(float)"}},"TargetPosition":{"label":{"name":"TargetPosition","type":"(float)"}},"MotorMaxForce":{"label":{"name":"MotorMaxForce","type":"(float)"}},"Restitution":{"label":{"name":"Restitution","type":"(float)"}},"Speed":{"label":{"name":"Speed","type":"(float)"}},"ServoMaxForce":{"label":{"name":"ServoMaxForce","type":"(float)"}},"SoftlockServoUponReachingTarget":{"label":{"name":"SoftlockServoUponReachingTarget","type":"(bool)"}},"ActuatorType":{"label":{"name":"ActuatorType","type":"(ActuatorType)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"RootPart":{"label":{"name":"RootPart","type":"(BasePart)"}},"FacingDirection":{"label":{"name":"FacingDirection","type":"(Vector3)"}},"BaseTurnSpeed":{"label":{"name":"BaseTurnSpeed","type":"(float)"}},"BaseMoveSpeed":{"label":{"name":"BaseMoveSpeed","type":"(float)"}},"ClimbSensor":{"label":{"name":"ClimbSensor","type":"(ControllerSensor)"}},"MovingDirection":{"label":{"name":"MovingDirection","type":"(Vector3)"}},"ActiveController":{"label":{"name":"ActiveController","type":"(ControllerBase)"}},"GroundSensor":{"label":{"name":"GroundSensor","type":"(ControllerSensor)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
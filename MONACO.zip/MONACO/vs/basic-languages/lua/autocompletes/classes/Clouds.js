define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Color":{"label":{"name":"Color","type":"(Color3)"}},"Enabled":{"label":{"name":"Enabled","type":"(bool)"}},"Density":{"label":{"name":"Density","type":"(float)"}},"Cover":{"label":{"name":"Cover","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Color3":{"label":{"name":"Color3","type":"(Color3)"}},"Graphic":{"label":{"name":"Graphic","type":"(Content)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
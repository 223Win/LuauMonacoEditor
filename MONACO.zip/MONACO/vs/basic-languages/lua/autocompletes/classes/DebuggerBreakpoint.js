define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Line":{"label":{"name":"Line","type":"(int)"}},"line":{"label":{"name":"line","type":"(int)"}},"ContinueExecution":{"label":{"name":"ContinueExecution","type":"(bool)"}},"IsEnabled":{"label":{"name":"IsEnabled","type":"(bool)"}},"isContextDependentBreakpoint":{"label":{"name":"isContextDependentBreakpoint","type":"(bool)"}},"Condition":{"label":{"name":"Condition","type":"(string)"}},"LogExpression":{"label":{"name":"LogExpression","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Enabled":{"label":{"name":"Enabled","type":"(bool)"}},"TeamColor":{"label":{"name":"TeamColor","type":"(BrickColor)"}},"Neutral":{"label":{"name":"Neutral","type":"(bool)"}},"Duration":{"label":{"name":"Duration","type":"(int)"}},"AllowTeamChangeOnTouch":{"label":{"name":"AllowTeamChangeOnTouch","type":"(bool)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
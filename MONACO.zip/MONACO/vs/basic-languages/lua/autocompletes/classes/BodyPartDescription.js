define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Color":{"label":{"name":"Color","type":"(Color3)"}},"AssetId":{"label":{"name":"AssetId","type":"(int64)"}},"Instance":{"label":{"name":"Instance","type":"(Instance)"}},"BodyPart":{"label":{"name":"BodyPart","type":"(BodyPart)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
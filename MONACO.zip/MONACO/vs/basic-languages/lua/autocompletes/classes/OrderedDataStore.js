define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"GetSortedAsync":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/OrderedDataStore/GetSortedAsync)"]},"insertText":"GetSortedAsync(${1:ascending}, ${2:pagesize}, ${3:minValue}, ${4:maxValue}) \n\t\nend","label":{"name":"GetSortedAsync","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Color":{"label":{"name":"Color","type":"(Color3)"}},"Brightness":{"label":{"name":"Brightness","type":"(float)"}},"Shadows":{"label":{"name":"Shadows","type":"(bool)"}},"Enabled":{"label":{"name":"Enabled","type":"(bool)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
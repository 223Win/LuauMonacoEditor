define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"TeamColor":{"label":{"name":"TeamColor","type":"(BrickColor)"}}},"Event":{"FlagCaptured":{"label":{"name":"FlagCaptured","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/FlagStand/FlagCaptured)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
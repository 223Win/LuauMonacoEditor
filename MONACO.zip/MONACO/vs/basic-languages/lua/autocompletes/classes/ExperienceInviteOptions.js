define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"LaunchData":{"label":{"name":"LaunchData","type":"(string)"}},"PromptMessage":{"label":{"name":"PromptMessage","type":"(string)"}},"InviteUser":{"label":{"name":"InviteUser","type":"(int64)"}},"InviteMessageId":{"label":{"name":"InviteMessageId","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
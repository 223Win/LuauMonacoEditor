define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"MoveMaxForce":{"label":{"name":"MoveMaxForce","type":"(float)"}},"BalanceSpeed":{"label":{"name":"BalanceSpeed","type":"(float)"}},"BalanceMaxTorque":{"label":{"name":"BalanceMaxTorque","type":"(float)"}},"AccelerationTime":{"label":{"name":"AccelerationTime","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
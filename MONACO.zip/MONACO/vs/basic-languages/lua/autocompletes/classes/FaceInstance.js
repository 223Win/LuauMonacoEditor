define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Face":{"label":{"name":"Face","type":"(NormalId)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
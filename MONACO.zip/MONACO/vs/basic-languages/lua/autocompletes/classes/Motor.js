define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"CurrentAngle":{"label":{"name":"CurrentAngle","type":"(float)"}},"DesiredAngle":{"label":{"name":"DesiredAngle","type":"(float)"}},"MaxVelocity":{"label":{"name":"MaxVelocity","type":"(float)"}}},"Event":[],"Method":{"SetDesiredAngle":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Motor/SetDesiredAngle)"]},"insertText":"SetDesiredAngle(${1:value}) \n\t\nend","label":{"name":"SetDesiredAngle","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
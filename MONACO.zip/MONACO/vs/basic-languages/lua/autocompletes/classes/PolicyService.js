define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"LuobuWhitelisted":{"label":{"name":"LuobuWhitelisted","type":"(TriStateBoolean)"}},"IsLuobuServer":{"label":{"name":"IsLuobuServer","type":"(TriStateBoolean)"}}},"Event":[],"Method":{"GetPolicyInfoForPlayerAsync":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PolicyService/GetPolicyInfoForPlayerAsync)"]},"insertText":"GetPolicyInfoForPlayerAsync(${1:player}) \n\t\nend","label":{"name":"GetPolicyInfoForPlayerAsync","type":"(Function)"}},"GetPolicyInfoForServerRobloxOnlyAsync":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PolicyService/GetPolicyInfoForServerRobloxOnlyAsync)"]},"insertText":"GetPolicyInfoForServerRobloxOnlyAsync() \n\t\nend","label":{"name":"GetPolicyInfoForServerRobloxOnlyAsync","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
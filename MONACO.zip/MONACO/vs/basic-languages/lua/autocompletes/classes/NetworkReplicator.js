define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"GetPlayer":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/NetworkReplicator/GetPlayer)"]},"insertText":"GetPlayer() \n\t\nend","label":{"name":"GetPlayer","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
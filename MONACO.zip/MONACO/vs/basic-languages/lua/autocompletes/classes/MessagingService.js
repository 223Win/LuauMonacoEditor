define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"PublishAsync":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/MessagingService/PublishAsync)"]},"insertText":"PublishAsync(${1:topic}, ${2:message}) \n\t\nend","label":{"name":"PublishAsync","type":"(Function)"}},"SubscribeAsync":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/MessagingService/SubscribeAsync)"]},"insertText":"SubscribeAsync(${1:topic}, ${2:callback}) \n\t\nend","label":{"name":"SubscribeAsync","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
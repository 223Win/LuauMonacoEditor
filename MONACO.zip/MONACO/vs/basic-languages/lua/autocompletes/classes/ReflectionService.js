define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"GetPropertyNames":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ReflectionService/GetPropertyNames)"]},"insertText":"GetPropertyNames(${1:name}) \n\t\nend","label":{"name":"GetPropertyNames","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
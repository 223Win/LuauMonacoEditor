define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Enabled":{"label":{"name":"Enabled","type":"(bool)"}},"Active":{"label":{"name":"Active","type":"(bool)"}},"Color":{"label":{"name":"Color","type":"(BrickColor)"}},"Visible":{"label":{"name":"Visible","type":"(bool)"}},"Attachment0":{"label":{"name":"Attachment0","type":"(Attachment)"}},"Attachment1":{"label":{"name":"Attachment1","type":"(Attachment)"}}},"Event":[],"Method":{"GetDebugAppliedTorque":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Constraint/GetDebugAppliedTorque)"]},"insertText":"GetDebugAppliedTorque(${1:bodyId}) \n\t\nend","label":{"name":"GetDebugAppliedTorque","type":"(Function)"}},"GetDebugAppliedForce":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Constraint/GetDebugAppliedForce)"]},"insertText":"GetDebugAppliedForce(${1:bodyId}) \n\t\nend","label":{"name":"GetDebugAppliedForce","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
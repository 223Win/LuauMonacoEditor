define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"GetScriptFilePath":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/CoreScriptSyncService/GetScriptFilePath)"]},"insertText":"GetScriptFilePath(${1:script}) \n\t\nend","label":{"name":"GetScriptFilePath","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
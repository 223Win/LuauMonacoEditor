define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":{"RomarkEndOfTest":{"label":{"name":"RomarkEndOfTest","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/RomarkService/RomarkEndOfTest)"]}}},"Method":{"EndRemoteRomarkTest":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/RomarkService/EndRemoteRomarkTest)"]},"insertText":"EndRemoteRomarkTest() \n\t\nend","label":{"name":"EndRemoteRomarkTest","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
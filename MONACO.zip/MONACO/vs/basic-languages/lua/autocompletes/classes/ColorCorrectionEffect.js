define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"TintColor":{"label":{"name":"TintColor","type":"(Color3)"}},"Brightness":{"label":{"name":"Brightness","type":"(float)"}},"Saturation":{"label":{"name":"Saturation","type":"(float)"}},"Contrast":{"label":{"name":"Contrast","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
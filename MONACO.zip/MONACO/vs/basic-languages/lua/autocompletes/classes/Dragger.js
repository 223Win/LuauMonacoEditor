define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"MouseDown":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Dragger/MouseDown)"]},"insertText":"MouseDown(${1:mousePart}, ${2:pointOnMousePart}, ${3:parts}) \n\t\nend","label":{"name":"MouseDown","type":"(Function)"}},"AxisRotate":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Dragger/AxisRotate)"]},"insertText":"AxisRotate(${1:axis}) \n\t\nend","label":{"name":"AxisRotate","type":"(Function)"}},"MouseMove":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Dragger/MouseMove)"]},"insertText":"MouseMove(${1:mouseRay}) \n\t\nend","label":{"name":"MouseMove","type":"(Function)"}},"MouseUp":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Dragger/MouseUp)"]},"insertText":"MouseUp() \n\t\nend","label":{"name":"MouseUp","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
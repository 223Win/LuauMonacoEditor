define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Visible":{"label":{"name":"Visible","type":"(bool)"}},"CameraButtonIcon":{"label":{"name":"CameraButtonIcon","type":"(Content)"}},"HidePlayerGuiForCaptures":{"label":{"name":"HidePlayerGuiForCaptures","type":"(bool)"}},"CloseWhenScreenshotTaken":{"label":{"name":"CloseWhenScreenshotTaken","type":"(bool)"}},"ExperienceNameOverlayEnabled":{"label":{"name":"ExperienceNameOverlayEnabled","type":"(bool)"}},"CameraButtonPosition":{"label":{"name":"CameraButtonPosition","type":"(UDim2)"}},"UsernameOverlayEnabled":{"label":{"name":"UsernameOverlayEnabled","type":"(bool)"}},"HideCoreGuiForCaptures":{"label":{"name":"HideCoreGuiForCaptures","type":"(bool)"}},"OverlayFont":{"label":{"name":"OverlayFont","type":"(Font)"}},"CloseButtonPosition":{"label":{"name":"CloseButtonPosition","type":"(UDim2)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Adornee":{"label":{"name":"Adornee","type":"(Instance)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
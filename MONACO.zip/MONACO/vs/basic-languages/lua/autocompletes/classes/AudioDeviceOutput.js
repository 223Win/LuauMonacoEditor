define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Player":{"label":{"name":"Player","type":"(Player)"}}},"Event":[],"Method":{"GetConnectedWires":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AudioDeviceOutput/GetConnectedWires)"]},"insertText":"GetConnectedWires(${1:pin}) \n\t\nend","label":{"name":"GetConnectedWires","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
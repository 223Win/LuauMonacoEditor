define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":{"Event":{"label":{"name":"Event","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/BindableEvent/Event)"]}}},"Method":{"Fire":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/BindableEvent/Fire)"]},"insertText":"Fire(${1:arguments}) \n\t\nend","label":{"name":"Fire","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
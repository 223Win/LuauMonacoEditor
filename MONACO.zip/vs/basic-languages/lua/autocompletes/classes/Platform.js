define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":{"RemoteDestroyMotor6D":{"label":{"name":"RemoteDestroyMotor6D","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Platform/RemoteDestroyMotor6D)"]}},"RemoteCreateMotor6D":{"label":{"name":"RemoteCreateMotor6D","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Platform/RemoteCreateMotor6D)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
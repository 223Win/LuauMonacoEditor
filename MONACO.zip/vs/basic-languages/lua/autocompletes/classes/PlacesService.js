define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"StopPlaySolo":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PlacesService/StopPlaySolo)"]},"insertText":"StopPlaySolo() \n\t\nend","label":{"name":"StopPlaySolo","type":"(Function)"}},"StartPlaySolo":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PlacesService/StartPlaySolo)"]},"insertText":"StartPlaySolo() \n\t\nend","label":{"name":"StartPlaySolo","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
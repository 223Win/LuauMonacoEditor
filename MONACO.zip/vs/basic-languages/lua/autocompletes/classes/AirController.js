define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"LinearImpulse":{"label":{"name":"LinearImpulse","type":"(Vector3)"}},"TurnSpeedFactor":{"label":{"name":"TurnSpeedFactor","type":"(float)"}},"BalanceMaxTorque":{"label":{"name":"BalanceMaxTorque","type":"(float)"}},"MoveMaxForce":{"label":{"name":"MoveMaxForce","type":"(float)"}},"MaintainAngularMomentum":{"label":{"name":"MaintainAngularMomentum","type":"(bool)"}},"BalanceSpeed":{"label":{"name":"BalanceSpeed","type":"(float)"}},"TurnMaxTorque":{"label":{"name":"TurnMaxTorque","type":"(float)"}},"MaintainLinearMomentum":{"label":{"name":"MaintainLinearMomentum","type":"(bool)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
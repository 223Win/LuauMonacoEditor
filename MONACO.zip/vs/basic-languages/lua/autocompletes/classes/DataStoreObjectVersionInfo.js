define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"CreatedTime":{"label":{"name":"CreatedTime","type":"(int64)"}},"IsDeleted":{"label":{"name":"IsDeleted","type":"(bool)"}},"Version":{"label":{"name":"Version","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
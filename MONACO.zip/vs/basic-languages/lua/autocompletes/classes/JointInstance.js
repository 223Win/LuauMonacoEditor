define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Enabled":{"label":{"name":"Enabled","type":"(bool)"}},"Part1":{"label":{"name":"Part1","type":"(BasePart)"}},"Active":{"label":{"name":"Active","type":"(bool)"}},"C1":{"label":{"name":"C1","type":"(CFrame)"}},"C0":{"label":{"name":"C0","type":"(CFrame)"}},"part1":{"label":{"name":"part1","type":"(BasePart)"}},"Part0":{"label":{"name":"Part0","type":"(BasePart)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
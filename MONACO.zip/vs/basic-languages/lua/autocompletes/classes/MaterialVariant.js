define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"ColorMap":{"label":{"name":"ColorMap","type":"(Content)"}},"NormalMap":{"label":{"name":"NormalMap","type":"(Content)"}},"BaseMaterial":{"label":{"name":"BaseMaterial","type":"(Material)"}},"AvgRoughness":{"label":{"name":"AvgRoughness","type":"(int)"}},"MetalnessMap":{"label":{"name":"MetalnessMap","type":"(Content)"}},"TexturePack":{"label":{"name":"TexturePack","type":"(Content)"}},"RoughnessMap":{"label":{"name":"RoughnessMap","type":"(Content)"}},"MaterialPattern":{"label":{"name":"MaterialPattern","type":"(MaterialPattern)"}},"StudsPerTile":{"label":{"name":"StudsPerTile","type":"(float)"}},"AvgMetalness":{"label":{"name":"AvgMetalness","type":"(int)"}},"CustomPhysicalProperties":{"label":{"name":"CustomPhysicalProperties","type":"(PhysicalProperties)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
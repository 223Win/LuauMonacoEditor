define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"ThreadId":{"label":{"name":"ThreadId","type":"(int)"}},"AllThreadsPaused":{"label":{"name":"AllThreadsPaused","type":"(bool)"}},"Reason":{"label":{"name":"Reason","type":"(DebuggerPauseReason)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"TeamColor":{"label":{"name":"TeamColor","type":"(BrickColor)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
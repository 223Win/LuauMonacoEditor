define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"WinchResponsiveness":{"label":{"name":"WinchResponsiveness","type":"(float)"}},"WinchTarget":{"label":{"name":"WinchTarget","type":"(float)"}},"WinchEnabled":{"label":{"name":"WinchEnabled","type":"(bool)"}},"Thickness":{"label":{"name":"Thickness","type":"(float)"}},"WinchForce":{"label":{"name":"WinchForce","type":"(float)"}},"Restitution":{"label":{"name":"Restitution","type":"(float)"}},"Length":{"label":{"name":"Length","type":"(float)"}},"CurrentDistance":{"label":{"name":"CurrentDistance","type":"(float)"}},"WinchSpeed":{"label":{"name":"WinchSpeed","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
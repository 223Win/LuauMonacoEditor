define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"BaseAngle":{"label":{"name":"BaseAngle","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
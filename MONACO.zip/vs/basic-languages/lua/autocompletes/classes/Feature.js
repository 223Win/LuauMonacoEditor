define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"LeftRight":{"label":{"name":"LeftRight","type":"(LeftRight)"}},"InOut":{"label":{"name":"InOut","type":"(InOut)"}},"TopBottom":{"label":{"name":"TopBottom","type":"(TopBottom)"}},"FaceId":{"label":{"name":"FaceId","type":"(NormalId)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
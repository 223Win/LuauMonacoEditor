define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Transform":{"label":{"name":"Transform","type":"(CFrame)"}},"TransformedWorldCFrame":{"label":{"name":"TransformedWorldCFrame","type":"(CFrame)"}},"TransformedCFrame":{"label":{"name":"TransformedCFrame","type":"(CFrame)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
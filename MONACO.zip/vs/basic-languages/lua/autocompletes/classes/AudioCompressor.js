define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"MakeupGain":{"label":{"name":"MakeupGain","type":"(float)"}},"Release":{"label":{"name":"Release","type":"(float)"}},"Ratio":{"label":{"name":"Ratio","type":"(float)"}},"Threshold":{"label":{"name":"Threshold","type":"(float)"}},"Attack":{"label":{"name":"Attack","type":"(float)"}}},"Event":[],"Method":{"GetConnectedWires":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AudioCompressor/GetConnectedWires)"]},"insertText":"GetConnectedWires(${1:pin}) \n\t\nend","label":{"name":"GetConnectedWires","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Label":{"label":{"name":"Label","type":"(string)"}},"Attachment1":{"label":{"name":"Attachment1","type":"(Attachment)"}},"IsBidirectional":{"label":{"name":"IsBidirectional","type":"(bool)"}},"Attachment0":{"label":{"name":"Attachment0","type":"(Attachment)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
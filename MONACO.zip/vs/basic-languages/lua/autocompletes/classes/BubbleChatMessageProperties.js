define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"TailVisible":{"label":{"name":"TailVisible","type":"(bool)"}},"FontFace":{"label":{"name":"FontFace","type":"(Font)"}},"BackgroundTransparency":{"label":{"name":"BackgroundTransparency","type":"(double)"}},"TextColor3":{"label":{"name":"TextColor3","type":"(Color3)"}},"TextSize":{"label":{"name":"TextSize","type":"(int64)"}},"BackgroundColor3":{"label":{"name":"BackgroundColor3","type":"(Color3)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Port":{"label":{"name":"Port","type":"(int)"}},"StartServer":{"label":{"name":"StartServer","type":"(bool)"}},"Interface":{"label":{"name":"Interface","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
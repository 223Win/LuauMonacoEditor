define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"Start":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/HttpRequest/Start)"]},"insertText":"Start(${1:callback}) \n\t\nend","label":{"name":"Start","type":"(Function)"}},"Cancel":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/HttpRequest/Cancel)"]},"insertText":"Cancel() \n\t\nend","label":{"name":"Cancel","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
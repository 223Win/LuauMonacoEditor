define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"Disconnect":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/MemStorageConnection/Disconnect)"]},"insertText":"Disconnect() \n\t\nend","label":{"name":"Disconnect","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
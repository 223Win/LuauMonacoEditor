define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"GroupColor3":{"label":{"name":"GroupColor3","type":"(Color3)"}},"GroupTransparency":{"label":{"name":"GroupTransparency","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
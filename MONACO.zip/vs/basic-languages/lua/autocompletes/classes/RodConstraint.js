define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"LimitAngle0":{"label":{"name":"LimitAngle0","type":"(float)"}},"Thickness":{"label":{"name":"Thickness","type":"(float)"}},"LimitsEnabled":{"label":{"name":"LimitsEnabled","type":"(bool)"}},"Length":{"label":{"name":"Length","type":"(float)"}},"CurrentDistance":{"label":{"name":"CurrentDistance","type":"(float)"}},"LimitAngle1":{"label":{"name":"LimitAngle1","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
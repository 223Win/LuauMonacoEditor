define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"InFocusRadius":{"label":{"name":"InFocusRadius","type":"(float)"}},"FarIntensity":{"label":{"name":"FarIntensity","type":"(float)"}},"FocusDistance":{"label":{"name":"FocusDistance","type":"(float)"}},"NearIntensity":{"label":{"name":"NearIntensity","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
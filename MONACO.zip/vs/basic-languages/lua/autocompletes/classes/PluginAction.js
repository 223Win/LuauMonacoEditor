define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Enabled":{"label":{"name":"Enabled","type":"(bool)"}},"Checked":{"label":{"name":"Checked","type":"(bool)"}},"AllowBinding":{"label":{"name":"AllowBinding","type":"(bool)"}},"DefaultShortcut":{"label":{"name":"DefaultShortcut","type":"(string)"}},"Text":{"label":{"name":"Text","type":"(string)"}},"ActionId":{"label":{"name":"ActionId","type":"(string)"}},"StatusTip":{"label":{"name":"StatusTip","type":"(string)"}}},"Event":{"Triggered":{"label":{"name":"Triggered","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PluginAction/Triggered)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
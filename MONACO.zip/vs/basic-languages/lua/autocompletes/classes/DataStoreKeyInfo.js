define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"CreatedTime":{"label":{"name":"CreatedTime","type":"(int64)"}},"UpdatedTime":{"label":{"name":"UpdatedTime","type":"(int64)"}},"Version":{"label":{"name":"Version","type":"(string)"}}},"Event":[],"Method":{"GetMetadata":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/DataStoreKeyInfo/GetMetadata)"]},"insertText":"GetMetadata() \n\t\nend","label":{"name":"GetMetadata","type":"(Function)"}},"GetUserIds":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/DataStoreKeyInfo/GetUserIds)"]},"insertText":"GetUserIds() \n\t\nend","label":{"name":"GetUserIds","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Message":{"label":{"name":"Message","type":"(string)"}},"IsError":{"label":{"name":"IsError","type":"(bool)"}},"Status":{"label":{"name":"Status","type":"(DebuggerStatus)"}},"IsSuccess":{"label":{"name":"IsSuccess","type":"(bool)"}},"RequestId":{"label":{"name":"RequestId","type":"(int)"}}},"Event":[],"Method":{"GetArg":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/DebuggerLuaResponse/GetArg)"]},"insertText":"GetArg() \n\t\nend","label":{"name":"GetArg","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"CycleOffset":{"label":{"name":"CycleOffset","type":"(float)"}},"WireRadius":{"label":{"name":"WireRadius","type":"(float)"}},"TextureSize":{"label":{"name":"TextureSize","type":"(Vector2)"}},"From":{"label":{"name":"From","type":"(BasePart)"}},"To":{"label":{"name":"To","type":"(BasePart)"}},"Velocity":{"label":{"name":"Velocity","type":"(float)"}},"StudsBetweenTextures":{"label":{"name":"StudsBetweenTextures","type":"(float)"}},"Texture":{"label":{"name":"Texture","type":"(Content)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
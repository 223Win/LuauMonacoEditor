define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"formFactor":{"label":{"name":"formFactor","type":"(FormFactor)"}},"formFactorRaw":{"label":{"name":"formFactorRaw","type":"(FormFactor)"}},"FormFactor":{"label":{"name":"FormFactor","type":"(FormFactor)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"PatchId":{"label":{"name":"PatchId","type":"(string)"}},"ContentId":{"label":{"name":"ContentId","type":"(string)"}},"OutputPath":{"label":{"name":"OutputPath","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Threshold":{"label":{"name":"Threshold","type":"(float)"}},"Intensity":{"label":{"name":"Intensity","type":"(float)"}},"Size":{"label":{"name":"Size","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
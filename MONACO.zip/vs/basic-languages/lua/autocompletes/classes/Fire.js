define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Enabled":{"label":{"name":"Enabled","type":"(bool)"}},"Heat":{"label":{"name":"Heat","type":"(float)"}},"heat_xml":{"label":{"name":"heat_xml","type":"(float)"}},"SecondaryColor":{"label":{"name":"SecondaryColor","type":"(Color3)"}},"size_xml":{"label":{"name":"size_xml","type":"(float)"}},"TimeScale":{"label":{"name":"TimeScale","type":"(float)"}},"size":{"label":{"name":"size","type":"(float)"}},"Color":{"label":{"name":"Color","type":"(Color3)"}},"Size":{"label":{"name":"Size","type":"(float)"}}},"Event":[],"Method":{"FastForward":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Fire/FastForward)"]},"insertText":"FastForward(${1:numFrames}) \n\t\nend","label":{"name":"FastForward","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
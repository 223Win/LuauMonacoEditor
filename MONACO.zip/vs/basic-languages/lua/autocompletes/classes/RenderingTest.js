define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"ComparisonDiffThreshold":{"label":{"name":"ComparisonDiffThreshold","type":"(int)"}},"FieldOfView":{"label":{"name":"FieldOfView","type":"(float)"}},"Description":{"label":{"name":"Description","type":"(string)"}},"CFrame":{"label":{"name":"CFrame","type":"(CFrame)"}},"ComparisonMethod":{"label":{"name":"ComparisonMethod","type":"(RenderingTestComparisonMethod)"}},"Timeout":{"label":{"name":"Timeout","type":"(int)"}},"Ticket":{"label":{"name":"Ticket","type":"(string)"}},"QualityLevel":{"label":{"name":"QualityLevel","type":"(int)"}},"Position":{"label":{"name":"Position","type":"(Vector3)"}},"Orientation":{"label":{"name":"Orientation","type":"(Vector3)"}},"ComparisonPsnrThreshold":{"label":{"name":"ComparisonPsnrThreshold","type":"(float)"}},"ShouldSkip":{"label":{"name":"ShouldSkip","type":"(bool)"}},"PerfTest":{"label":{"name":"PerfTest","type":"(bool)"}}},"Event":[],"Method":{"RenderdocTriggerCapture":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/RenderingTest/RenderdocTriggerCapture)"]},"insertText":"RenderdocTriggerCapture() \n\t\nend","label":{"name":"RenderdocTriggerCapture","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
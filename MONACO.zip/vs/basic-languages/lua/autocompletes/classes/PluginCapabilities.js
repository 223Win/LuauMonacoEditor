define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Manifest":{"label":{"name":"Manifest","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"AllScopes":{"label":{"name":"AllScopes","type":"(bool)"}}},"Event":[],"Method":{"SetExperimentalFeatures":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/DataStoreOptions/SetExperimentalFeatures)"]},"insertText":"SetExperimentalFeatures(${1:experimentalFeatures}) \n\t\nend","label":{"name":"SetExperimentalFeatures","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Size":{"label":{"name":"Size","type":"(int64)"}}},"Event":[],"Method":{"GetTemporaryId":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/File/GetTemporaryId)"]},"insertText":"GetTemporaryId() \n\t\nend","label":{"name":"GetTemporaryId","type":"(Function)"}},"GetBinaryContents":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/File/GetBinaryContents)"]},"insertText":"GetBinaryContents() \n\t\nend","label":{"name":"GetBinaryContents","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"AllowSleep":{"label":{"name":"AllowSleep","type":"(bool)"}},"Description":{"label":{"name":"Description","type":"(string)"}},"Is30FpsThrottleEnabled":{"label":{"name":"Is30FpsThrottleEnabled","type":"(bool)"}},"HasMigratedSettingsToTestService":{"label":{"name":"HasMigratedSettingsToTestService","type":"(bool)"}},"Timeout":{"label":{"name":"Timeout","type":"(double)"}},"PhysicsEnvironmentalThrottle":{"label":{"name":"PhysicsEnvironmentalThrottle","type":"(bool)"}}},"Event":[],"Method":{"Warn":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/FunctionalTest/Warn)"]},"insertText":"Warn(${1:message}) \n\t\nend","label":{"name":"Warn","type":"(Function)"}},"Passed":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/FunctionalTest/Passed)"]},"insertText":"Passed(${1:message}) \n\t\nend","label":{"name":"Passed","type":"(Function)"}},"Pass":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/FunctionalTest/Pass)"]},"insertText":"Pass(${1:message}) \n\t\nend","label":{"name":"Pass","type":"(Function)"}},"Error":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/FunctionalTest/Error)"]},"insertText":"Error(${1:message}) \n\t\nend","label":{"name":"Error","type":"(Function)"}},"Failed":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/FunctionalTest/Failed)"]},"insertText":"Failed(${1:message}) \n\t\nend","label":{"name":"Failed","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
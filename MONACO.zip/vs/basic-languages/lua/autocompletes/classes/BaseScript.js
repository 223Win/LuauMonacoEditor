define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Enabled":{"label":{"name":"Enabled","type":"(bool)"}},"LinkedSource":{"label":{"name":"LinkedSource","type":"(Content)"}},"Disabled":{"label":{"name":"Disabled","type":"(bool)"}},"RunContext":{"label":{"name":"RunContext","type":"(RunContext)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
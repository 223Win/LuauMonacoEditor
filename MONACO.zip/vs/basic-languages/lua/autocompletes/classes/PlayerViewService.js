define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"GetDeviceCameraCFrame":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PlayerViewService/GetDeviceCameraCFrame)"]},"insertText":"GetDeviceCameraCFrame(${1:player}) \n\t\nend","label":{"name":"GetDeviceCameraCFrame","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
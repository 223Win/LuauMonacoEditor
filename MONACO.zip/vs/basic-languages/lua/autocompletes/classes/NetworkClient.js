define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":{"ConnectionAccepted":{"label":{"name":"ConnectionAccepted","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/NetworkClient/ConnectionAccepted)"]}},"ConnectionFailed":{"label":{"name":"ConnectionFailed","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/NetworkClient/ConnectionFailed)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"SurfaceTransparency":{"label":{"name":"SurfaceTransparency","type":"(float)"}},"SurfaceColor3":{"label":{"name":"SurfaceColor3","type":"(Color3)"}},"SurfaceColor":{"label":{"name":"SurfaceColor","type":"(BrickColor)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
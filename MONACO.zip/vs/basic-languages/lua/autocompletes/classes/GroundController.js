define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Friction":{"label":{"name":"Friction","type":"(float)"}},"TurnSpeedFactor":{"label":{"name":"TurnSpeedFactor","type":"(float)"}},"AccelerationTime":{"label":{"name":"AccelerationTime","type":"(float)"}},"AccelerationLean":{"label":{"name":"AccelerationLean","type":"(float)"}},"FrictionWeight":{"label":{"name":"FrictionWeight","type":"(float)"}},"BalanceMaxTorque":{"label":{"name":"BalanceMaxTorque","type":"(float)"}},"StandSpeed":{"label":{"name":"StandSpeed","type":"(float)"}},"StandForce":{"label":{"name":"StandForce","type":"(float)"}},"BalanceSpeed":{"label":{"name":"BalanceSpeed","type":"(float)"}},"GroundOffset":{"label":{"name":"GroundOffset","type":"(float)"}},"DecelerationTime":{"label":{"name":"DecelerationTime","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
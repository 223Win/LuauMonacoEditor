define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Outfit2":{"label":{"name":"Outfit2","type":"(Content)"}},"Color3":{"label":{"name":"Color3","type":"(Color3)"}},"Outfit1":{"label":{"name":"Outfit1","type":"(Content)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
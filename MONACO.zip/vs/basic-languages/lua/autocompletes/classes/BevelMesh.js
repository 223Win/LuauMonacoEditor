define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Bulge":{"label":{"name":"Bulge","type":"(float)"}},"Bevel Roundness":{"label":{"name":"Bevel Roundness","type":"(float)"}},"Bevel":{"label":{"name":"Bevel","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
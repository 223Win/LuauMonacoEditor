define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"GetContentMemoryData":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/MeshContentProvider/GetContentMemoryData)"]},"insertText":"GetContentMemoryData() \n\t\nend","label":{"name":"GetContentMemoryData","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
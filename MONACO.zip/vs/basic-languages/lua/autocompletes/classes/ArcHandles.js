define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"MouseEnterConnectionCount":{"label":{"name":"MouseEnterConnectionCount","type":"(int)"}},"MouseDragConnectionCount":{"label":{"name":"MouseDragConnectionCount","type":"(int)"}},"MouseButton1DownConnectionCount":{"label":{"name":"MouseButton1DownConnectionCount","type":"(int)"}},"Axes":{"label":{"name":"Axes","type":"(Axes)"}},"MouseLeaveConnectionCount":{"label":{"name":"MouseLeaveConnectionCount","type":"(int)"}},"MouseButton1UpConnectionCount":{"label":{"name":"MouseButton1UpConnectionCount","type":"(int)"}}},"Event":{"MouseButton1Down":{"label":{"name":"MouseButton1Down","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ArcHandles/MouseButton1Down)"]}},"MouseButton1Up":{"label":{"name":"MouseButton1Up","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ArcHandles/MouseButton1Up)"]}},"MouseDrag":{"label":{"name":"MouseDrag","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ArcHandles/MouseDrag)"]}},"MouseEnter":{"label":{"name":"MouseEnter","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ArcHandles/MouseEnter)"]}},"MouseLeave":{"label":{"name":"MouseLeave","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ArcHandles/MouseLeave)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
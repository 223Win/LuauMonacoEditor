define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Username":{"label":{"name":"Username","type":"(string)"}},"CollaboratorColor":{"label":{"name":"CollaboratorColor","type":"(int)"}},"Status":{"label":{"name":"Status","type":"(CollaboratorStatus)"}},"CurScriptLineNumber":{"label":{"name":"CurScriptLineNumber","type":"(int)"}},"CFrame":{"label":{"name":"CFrame","type":"(CFrame)"}},"UserId":{"label":{"name":"UserId","type":"(int64)"}},"CurDocGUID":{"label":{"name":"CurDocGUID","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
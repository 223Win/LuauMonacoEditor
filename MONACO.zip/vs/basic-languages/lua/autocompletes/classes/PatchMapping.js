define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"FlattenTree":{"label":{"name":"FlattenTree","type":"(bool)"}},"TargetPath":{"label":{"name":"TargetPath","type":"(string)"}},"PatchId":{"label":{"name":"PatchId","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
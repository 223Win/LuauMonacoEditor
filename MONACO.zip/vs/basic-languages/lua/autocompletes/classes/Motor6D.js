define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"ChildName":{"label":{"name":"ChildName","type":"(string)"}},"ParentName":{"label":{"name":"ParentName","type":"(string)"}},"Transform":{"label":{"name":"Transform","type":"(CFrame)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
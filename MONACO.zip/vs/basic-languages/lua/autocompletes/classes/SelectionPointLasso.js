define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Point":{"label":{"name":"Point","type":"(Vector3)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
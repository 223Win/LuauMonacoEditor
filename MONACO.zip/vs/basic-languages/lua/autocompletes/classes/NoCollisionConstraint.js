define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Part0":{"label":{"name":"Part0","type":"(BasePart)"}},"Part1":{"label":{"name":"Part1","type":"(BasePart)"}},"Enabled":{"label":{"name":"Enabled","type":"(bool)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":{"DragEnter":{"label":{"name":"DragEnter","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PluginMouse/DragEnter)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"ReplicatedGuiInsertionOrder":{"label":{"name":"ReplicatedGuiInsertionOrder","type":"(int)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
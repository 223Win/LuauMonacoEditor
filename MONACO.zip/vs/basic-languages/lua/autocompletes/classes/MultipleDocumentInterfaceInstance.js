define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"FocusedDataModelSession":{"label":{"name":"FocusedDataModelSession","type":"(Instance)"}}},"Event":{"DataModelSessionEnded":{"label":{"name":"DataModelSessionEnded","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/MultipleDocumentInterfaceInstance/DataModelSessionEnded)"]}},"DataModelSessionStarted":{"label":{"name":"DataModelSessionStarted","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/MultipleDocumentInterfaceInstance/DataModelSessionStarted)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
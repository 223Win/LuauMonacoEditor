define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"GetGuiObjectsInCircle":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/BasePlayerGui/GetGuiObjectsInCircle)"]},"insertText":"GetGuiObjectsInCircle(${1:position}, ${2:radius}) \n\t\nend","label":{"name":"GetGuiObjectsInCircle","type":"(Function)"}},"GetGuiObjectsAtPosition":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/BasePlayerGui/GetGuiObjectsAtPosition)"]},"insertText":"GetGuiObjectsAtPosition(${1:x}, ${2:y}) \n\t\nend","label":{"name":"GetGuiObjectsAtPosition","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
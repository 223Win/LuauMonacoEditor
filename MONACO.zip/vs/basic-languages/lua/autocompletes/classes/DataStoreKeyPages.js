define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Cursor":{"label":{"name":"Cursor","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
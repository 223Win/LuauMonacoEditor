define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"ImportVideoWithPrompt":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AnimationFromVideoCreatorStudioService/ImportVideoWithPrompt)"]},"insertText":"ImportVideoWithPrompt() \n\t\nend","label":{"name":"ImportVideoWithPrompt","type":"(Function)"}},"CreateAnimationByUploadingVideo":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AnimationFromVideoCreatorStudioService/CreateAnimationByUploadingVideo)"]},"insertText":"CreateAnimationByUploadingVideo(${1:progressCallback}) \n\t\nend","label":{"name":"CreateAnimationByUploadingVideo","type":"(Function)"}},"IsAgeRestricted":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AnimationFromVideoCreatorStudioService/IsAgeRestricted)"]},"insertText":"IsAgeRestricted() \n\t\nend","label":{"name":"IsAgeRestricted","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
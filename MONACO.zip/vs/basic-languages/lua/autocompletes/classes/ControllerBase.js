define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"MoveSpeedFactor":{"label":{"name":"MoveSpeedFactor","type":"(float)"}},"BalanceRigidityEnabled":{"label":{"name":"BalanceRigidityEnabled","type":"(bool)"}},"Active":{"label":{"name":"Active","type":"(bool)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
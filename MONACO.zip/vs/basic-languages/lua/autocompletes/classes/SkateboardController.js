define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Throttle":{"label":{"name":"Throttle","type":"(float)"}},"Steer":{"label":{"name":"Steer","type":"(float)"}}},"Event":{"AxisChanged":{"label":{"name":"AxisChanged","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/SkateboardController/AxisChanged)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
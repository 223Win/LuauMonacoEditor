define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"shape":{"label":{"name":"shape","type":"(PartType)"}},"shap":{"label":{"name":"shap","type":"(PartType)"}},"Shape":{"label":{"name":"Shape","type":"(PartType)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
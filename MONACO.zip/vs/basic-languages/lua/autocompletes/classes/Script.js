define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Source":{"label":{"name":"Source","type":"(ProtectedString)"}}},"Event":[],"Method":{"GetHash":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Script/GetHash)"]},"insertText":"GetHash() \n\t\nend","label":{"name":"GetHash","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
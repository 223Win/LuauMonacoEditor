define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"CreateModel":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/OpenCloudApiV1/CreateModel)"]},"insertText":"CreateModel(${1:name}) \n\t\nend","label":{"name":"CreateModel","type":"(Function)"}},"CreateUserNotificationAsync":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/OpenCloudApiV1/CreateUserNotificationAsync)"]},"insertText":"CreateUserNotificationAsync(${1:user}, ${2:userNotification}) \n\t\nend","label":{"name":"CreateUserNotificationAsync","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Density":{"label":{"name":"Density","type":"(float)"}},"Offset":{"label":{"name":"Offset","type":"(float)"}},"Color":{"label":{"name":"Color","type":"(Color3)"}},"Glare":{"label":{"name":"Glare","type":"(float)"}},"Haze":{"label":{"name":"Haze","type":"(float)"}},"Decay":{"label":{"name":"Decay","type":"(Color3)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
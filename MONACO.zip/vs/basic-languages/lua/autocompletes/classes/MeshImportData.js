define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"MeshNoHoleDetected":{"label":{"name":"MeshNoHoleDetected","type":"(bool)"}},"Anchored":{"label":{"name":"Anchored","type":"(bool)"}},"NoOuterCageFarExtendedFromMesh":{"label":{"name":"NoOuterCageFarExtendedFromMesh","type":"(bool)"}},"CageUVMatched":{"label":{"name":"CageUVMatched","type":"(bool)"}},"CageUVMisMatchedPreview":{"label":{"name":"CageUVMisMatchedPreview","type":"(bool)"}},"CageNonManifoldPreview":{"label":{"name":"CageNonManifoldPreview","type":"(bool)"}},"MeshHoleDetectedPreview":{"label":{"name":"MeshHoleDetectedPreview","type":"(bool)"}},"IgnoreVertexColors":{"label":{"name":"IgnoreVertexColors","type":"(bool)"}},"CageMeshIntersectedPreview":{"label":{"name":"CageMeshIntersectedPreview","type":"(bool)"}},"UseImportedPivot":{"label":{"name":"UseImportedPivot","type":"(bool)"}},"PolygonCount":{"label":{"name":"PolygonCount","type":"(float)"}},"OuterCageFarExtendedFromMeshPreview":{"label":{"name":"OuterCageFarExtendedFromMeshPreview","type":"(bool)"}},"NoIrrelevantCageModified":{"label":{"name":"NoIrrelevantCageModified","type":"(bool)"}},"CageMeshNotIntersected":{"label":{"name":"CageMeshNotIntersected","type":"(bool)"}},"CageManifold":{"label":{"name":"CageManifold","type":"(bool)"}},"IrrelevantCageModifiedPreview":{"label":{"name":"IrrelevantCageModifiedPreview","type":"(bool)"}},"DoubleSided":{"label":{"name":"DoubleSided","type":"(bool)"}},"CageOverlappingVerticesPreview":{"label":{"name":"CageOverlappingVerticesPreview","type":"(bool)"}},"CageNoOverlappingVertices":{"label":{"name":"CageNoOverlappingVertices","type":"(bool)"}},"Dimensions":{"label":{"name":"Dimensions","type":"(Vector3)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
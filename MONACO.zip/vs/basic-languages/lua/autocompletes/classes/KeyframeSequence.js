define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"AuthoredHipHeight":{"label":{"name":"AuthoredHipHeight","type":"(float)"}}},"Event":[],"Method":{"GetKeyframes":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/KeyframeSequence/GetKeyframes)"]},"insertText":"GetKeyframes() \n\t\nend","label":{"name":"GetKeyframes","type":"(Function)"}},"RemoveKeyframe":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/KeyframeSequence/RemoveKeyframe)"]},"insertText":"RemoveKeyframe(${1:keyframe}) \n\t\nend","label":{"name":"RemoveKeyframe","type":"(Function)"}},"AddKeyframe":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/KeyframeSequence/AddKeyframe)"]},"insertText":"AddKeyframe(${1:keyframe}) \n\t\nend","label":{"name":"AddKeyframe","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"MouseLeaveConnectionCount":{"label":{"name":"MouseLeaveConnectionCount","type":"(int)"}},"Style":{"label":{"name":"Style","type":"(HandlesStyle)"}},"MouseDragConnectionCount":{"label":{"name":"MouseDragConnectionCount","type":"(int)"}},"MouseButton1DownConnectionCount":{"label":{"name":"MouseButton1DownConnectionCount","type":"(int)"}},"MouseEnterConnectionCount":{"label":{"name":"MouseEnterConnectionCount","type":"(int)"}},"Faces":{"label":{"name":"Faces","type":"(Faces)"}},"MouseButton1UpConnectionCount":{"label":{"name":"MouseButton1UpConnectionCount","type":"(int)"}}},"Event":{"MouseButton1Down":{"label":{"name":"MouseButton1Down","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Handles/MouseButton1Down)"]}},"MouseButton1Up":{"label":{"name":"MouseButton1Up","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Handles/MouseButton1Up)"]}},"MouseDrag":{"label":{"name":"MouseDrag","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Handles/MouseDrag)"]}},"MouseEnter":{"label":{"name":"MouseEnter","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Handles/MouseEnter)"]}},"MouseLeave":{"label":{"name":"MouseLeave","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Handles/MouseLeave)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
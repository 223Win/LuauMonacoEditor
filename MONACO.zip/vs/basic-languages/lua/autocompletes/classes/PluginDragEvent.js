define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Data":{"label":{"name":"Data","type":"(string)"}},"Sender":{"label":{"name":"Sender","type":"(string)"}},"MimeType":{"label":{"name":"MimeType","type":"(string)"}},"Position":{"label":{"name":"Position","type":"(Vector2)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
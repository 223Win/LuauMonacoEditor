define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"EasingStyle":{"label":{"name":"EasingStyle","type":"(PoseEasingStyle)"}},"Weight":{"label":{"name":"Weight","type":"(float)"}},"EasingDirection":{"label":{"name":"EasingDirection","type":"(PoseEasingDirection)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"CreateUserNotificationAsync":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ExperienceNotificationService/CreateUserNotificationAsync)"]},"insertText":"CreateUserNotificationAsync(${1:userId}, ${2:userNotification}) \n\t\nend","label":{"name":"CreateUserNotificationAsync","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"PackageId":{"label":{"name":"PackageId","type":"(Content)"}},"Creator":{"label":{"name":"Creator","type":"(string)"}},"VersionNumber":{"label":{"name":"VersionNumber","type":"(int64)"}},"VersionIdSerialize":{"label":{"name":"VersionIdSerialize","type":"(int64)"}},"Status":{"label":{"name":"Status","type":"(string)"}},"PermissionLevel":{"label":{"name":"PermissionLevel","type":"(PackagePermission)"}},"SerializedDefaultAttributes":{"label":{"name":"SerializedDefaultAttributes","type":"(BinaryString)"}},"ModifiedState":{"label":{"name":"ModifiedState","type":"(int)"}},"PackageGuid":{"label":{"name":"PackageGuid","type":"(int64)"}},"AutoUpdate":{"label":{"name":"AutoUpdate","type":"(bool)"}},"DefaultName":{"label":{"name":"DefaultName","type":"(string)"}},"PackageAssetName":{"label":{"name":"PackageAssetName","type":"(string)"}},"PackageIdSerialize":{"label":{"name":"PackageIdSerialize","type":"(Content)"}},"CanAutoUpdate":{"label":{"name":"CanAutoUpdate","type":"(bool)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
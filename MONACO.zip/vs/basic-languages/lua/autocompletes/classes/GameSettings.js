define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"VideoCaptureEnabled":{"label":{"name":"VideoCaptureEnabled","type":"(bool)"}},"VideoRecording":{"label":{"name":"VideoRecording","type":"(bool)"}}},"Event":{"VideoRecordingChangeRequest":{"label":{"name":"VideoRecordingChangeRequest","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/GameSettings/VideoRecordingChangeRequest)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"InsertInWorkspace":{"label":{"name":"InsertInWorkspace","type":"(bool)"}},"Anchored":{"label":{"name":"Anchored","type":"(bool)"}},"ImportAsModelAsset":{"label":{"name":"ImportAsModelAsset","type":"(bool)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
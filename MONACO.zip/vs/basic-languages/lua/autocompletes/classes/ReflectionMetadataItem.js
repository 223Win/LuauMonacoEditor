define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Browsable":{"label":{"name":"Browsable","type":"(bool)"}},"IsBackend":{"label":{"name":"IsBackend","type":"(bool)"}},"ServerOnly":{"label":{"name":"ServerOnly","type":"(bool)"}},"EditingDisabled":{"label":{"name":"EditingDisabled","type":"(bool)"}},"Deprecated":{"label":{"name":"Deprecated","type":"(bool)"}},"ScriptContext":{"label":{"name":"ScriptContext","type":"(string)"}},"SliderScaling":{"label":{"name":"SliderScaling","type":"(string)"}},"ClassCategory":{"label":{"name":"ClassCategory","type":"(string)"}},"UIMaximum":{"label":{"name":"UIMaximum","type":"(double)"}},"FFlag":{"label":{"name":"FFlag","type":"(string)"}},"UIMinimum":{"label":{"name":"UIMinimum","type":"(double)"}},"UINumTicks":{"label":{"name":"UINumTicks","type":"(double)"}},"ClientOnly":{"label":{"name":"ClientOnly","type":"(bool)"}},"PropertyOrder":{"label":{"name":"PropertyOrder","type":"(int)"}},"Constraint":{"label":{"name":"Constraint","type":"(string)"}},"EditorType":{"label":{"name":"EditorType","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
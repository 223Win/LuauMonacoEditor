define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"OnTopOfCoreBlur":{"label":{"name":"OnTopOfCoreBlur","type":"(bool)"}},"SafeAreaCompatibility":{"label":{"name":"SafeAreaCompatibility","type":"(SafeAreaCompatibility)"}},"ClipToDeviceSafeArea":{"label":{"name":"ClipToDeviceSafeArea","type":"(bool)"}},"IgnoreGuiInset":{"label":{"name":"IgnoreGuiInset","type":"(bool)"}},"ScreenInsets":{"label":{"name":"ScreenInsets","type":"(ScreenInsets)"}},"DisplayOrder":{"label":{"name":"DisplayOrder","type":"(int)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
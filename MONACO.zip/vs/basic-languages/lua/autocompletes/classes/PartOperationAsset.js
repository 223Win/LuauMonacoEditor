define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"ChildData":{"label":{"name":"ChildData","type":"(BinaryString)"}},"MeshData":{"label":{"name":"MeshData","type":"(BinaryString)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
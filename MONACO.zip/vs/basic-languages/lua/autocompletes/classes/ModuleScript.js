define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"LinkedSource":{"label":{"name":"LinkedSource","type":"(Content)"}},"Confidential":{"label":{"name":"Confidential","type":"(bool)"}},"Source":{"label":{"name":"Source","type":"(ProtectedString)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"AddPathsToBundle":{"label":{"name":"AddPathsToBundle","type":"(bool)"}},"ZstdCompression":{"label":{"name":"ZstdCompression","type":"(bool)"}},"HighCompression":{"label":{"name":"HighCompression","type":"(bool)"}},"SerializePatch":{"label":{"name":"SerializePatch","type":"(bool)"}},"BuildDebouncePeriod":{"label":{"name":"BuildDebouncePeriod","type":"(double)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
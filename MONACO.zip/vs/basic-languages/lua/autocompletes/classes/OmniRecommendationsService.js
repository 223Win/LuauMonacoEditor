define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"GetSessionId":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/OmniRecommendationsService/GetSessionId)"]},"insertText":"GetSessionId() \n\t\nend","label":{"name":"GetSessionId","type":"(Function)"}},"ClearSessionId":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/OmniRecommendationsService/ClearSessionId)"]},"insertText":"ClearSessionId() \n\t\nend","label":{"name":"ClearSessionId","type":"(Function)"}},"MakeRequest":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/OmniRecommendationsService/MakeRequest)"]},"insertText":"MakeRequest(${1:nextPageToken}) \n\t\nend","label":{"name":"MakeRequest","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"GetQueue":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/MemoryStoreService/GetQueue)"]},"insertText":"GetQueue(${1:name}, ${2:invisibilityTimeout}) \n\t\nend","label":{"name":"GetQueue","type":"(Function)"}},"GetSortedMap":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/MemoryStoreService/GetSortedMap)"]},"insertText":"GetSortedMap(${1:name}) \n\t\nend","label":{"name":"GetSortedMap","type":"(Function)"}},"GetHashMap":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/MemoryStoreService/GetHashMap)"]},"insertText":"GetHashMap(${1:name}) \n\t\nend","label":{"name":"GetHashMap","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
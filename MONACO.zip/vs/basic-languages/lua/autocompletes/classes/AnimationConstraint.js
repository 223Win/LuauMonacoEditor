define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Transform":{"label":{"name":"Transform","type":"(CFrame)"}},"Part1":{"label":{"name":"Part1","type":"(BasePart)"}},"Part0":{"label":{"name":"Part0","type":"(BasePart)"}},"MaxForce":{"label":{"name":"MaxForce","type":"(float)"}},"C1":{"label":{"name":"C1","type":"(CFrame)"}},"C0":{"label":{"name":"C0","type":"(CFrame)"}},"IsKinematic":{"label":{"name":"IsKinematic","type":"(bool)"}},"MaxTorque":{"label":{"name":"MaxTorque","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
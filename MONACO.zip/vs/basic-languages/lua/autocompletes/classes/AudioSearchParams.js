define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Artist":{"label":{"name":"Artist","type":"(string)"}},"MaxDuration":{"label":{"name":"MaxDuration","type":"(int)"}},"Album":{"label":{"name":"Album","type":"(string)"}},"Title":{"label":{"name":"Title","type":"(string)"}},"AudioSubType":{"label":{"name":"AudioSubType","type":"(AudioSubType)"}},"Tag":{"label":{"name":"Tag","type":"(string)"}},"AudioSubtype":{"label":{"name":"AudioSubtype","type":"(AudioSubType)"}},"MinDuration":{"label":{"name":"MinDuration","type":"(int)"}},"SearchKeyword":{"label":{"name":"SearchKeyword","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
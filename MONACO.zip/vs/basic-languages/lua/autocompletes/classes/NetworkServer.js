define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"EncryptStringForPlayerId":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/NetworkServer/EncryptStringForPlayerId)"]},"insertText":"EncryptStringForPlayerId(${1:toEncrypt}, ${2:playerId}) \n\t\nend","label":{"name":"EncryptStringForPlayerId","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
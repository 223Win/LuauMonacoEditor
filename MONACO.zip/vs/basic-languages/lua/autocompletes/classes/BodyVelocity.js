define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"P":{"label":{"name":"P","type":"(float)"}},"MaxForce":{"label":{"name":"MaxForce","type":"(Vector3)"}},"Velocity":{"label":{"name":"Velocity","type":"(Vector3)"}},"velocity":{"label":{"name":"velocity","type":"(Vector3)"}},"maxForce":{"label":{"name":"maxForce","type":"(Vector3)"}}},"Event":[],"Method":{"lastForce":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/BodyVelocity/lastForce)"]},"insertText":"lastForce() \n\t\nend","label":{"name":"lastForce","type":"(Function)"}},"GetLastForce":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/BodyVelocity/GetLastForce)"]},"insertText":"GetLastForce() \n\t\nend","label":{"name":"GetLastForce","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"transform":{"label":{"name":"transform","type":"(BinaryString)"}},"endEffectorRotationConstraint":{"label":{"name":"endEffectorRotationConstraint","type":"(BinaryString)"}},"label":{"label":{"name":"label","type":"(BinaryString)"}},"parent":{"label":{"name":"parent","type":"(BinaryString)"}},"postTransform":{"label":{"name":"postTransform","type":"(BinaryString)"}},"endEffectorWeight":{"label":{"name":"endEffectorWeight","type":"(BinaryString)"}},"rootMotion":{"label":{"name":"rootMotion","type":"(BinaryString)"}},"name":{"label":{"name":"name","type":"(BinaryString)"}},"weight":{"label":{"name":"weight","type":"(BinaryString)"}},"preTransform":{"label":{"name":"preTransform","type":"(BinaryString)"}},"articulatedJoint":{"label":{"name":"articulatedJoint","type":"(BinaryString)"}},"facsControl":{"label":{"name":"facsControl","type":"(BinaryString)"}},"endEffectorTranslationConstraint":{"label":{"name":"endEffectorTranslationConstraint","type":"(BinaryString)"}}},"Event":[],"Method":{"LoadFromHumanoid":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AnimationRigData/LoadFromHumanoid)"]},"insertText":"LoadFromHumanoid(${1:humanoid}) \n\t\nend","label":{"name":"LoadFromHumanoid","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
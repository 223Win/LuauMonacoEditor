define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"DeviceIntegrityAvailable":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AccountService/DeviceIntegrityAvailable)"]},"insertText":"DeviceIntegrityAvailable() \n\t\nend","label":{"name":"DeviceIntegrityAvailable","type":"(Function)"}},"GetDeviceIntegrityToken":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AccountService/GetDeviceIntegrityToken)"]},"insertText":"GetDeviceIntegrityToken(${1:data}) \n\t\nend","label":{"name":"GetDeviceIntegrityToken","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"EntityScale":{"label":{"name":"EntityScale","type":"(Vector3)"}},"EntityLodEnabled":{"label":{"name":"EntityLodEnabled","type":"(bool)"}},"EntityPosition":{"label":{"name":"EntityPosition","type":"(CFrame)"}},"EntitySource":{"label":{"name":"EntitySource","type":"(Instance)"}},"EntityData":{"label":{"name":"EntityData","type":"(SharedString)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
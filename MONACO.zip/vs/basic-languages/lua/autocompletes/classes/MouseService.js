define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":{"MouseLeaveStudioViewport":{"label":{"name":"MouseLeaveStudioViewport","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/MouseService/MouseLeaveStudioViewport)"]}},"MouseEnterStudioViewport":{"label":{"name":"MouseEnterStudioViewport","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/MouseService/MouseEnterStudioViewport)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
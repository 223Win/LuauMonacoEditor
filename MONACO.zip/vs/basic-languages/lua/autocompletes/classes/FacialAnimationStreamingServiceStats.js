define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"GetWithPlayerId":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/FacialAnimationStreamingServiceStats/GetWithPlayerId)"]},"insertText":"GetWithPlayerId(${1:label}, ${2:playerId}) \n\t\nend","label":{"name":"GetWithPlayerId","type":"(Function)"}},"Get":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/FacialAnimationStreamingServiceStats/Get)"]},"insertText":"Get(${1:label}) \n\t\nend","label":{"name":"Get","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
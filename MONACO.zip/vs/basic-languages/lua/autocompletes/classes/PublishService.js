define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"PublishDescendantAssets":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PublishService/PublishDescendantAssets)"]},"insertText":"PublishDescendantAssets(${1:instance}) \n\t\nend","label":{"name":"PublishDescendantAssets","type":"(Function)"}},"PublishCageMeshAsync":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PublishService/PublishCageMeshAsync)"]},"insertText":"PublishCageMeshAsync(${1:wrap}, ${2:cageType}) \n\t\nend","label":{"name":"PublishCageMeshAsync","type":"(Function)"}},"CreateAssetAndWaitForAssetId":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PublishService/CreateAssetAndWaitForAssetId)"]},"insertText":"CreateAssetAndWaitForAssetId(${1:instances}, ${2:operationId}, ${3:creatorType}, ${4:creatorId}, ${5:assetType}, ${6:name}, ${7:description}, ${8:expectedPrice}) \n\t\nend","label":{"name":"CreateAssetAndWaitForAssetId","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"PeakLevel":{"label":{"name":"PeakLevel","type":"(float)"}},"RmsLevel":{"label":{"name":"RmsLevel","type":"(float)"}}},"Event":[],"Method":{"GetSpectrum":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AudioAnalyzer/GetSpectrum)"]},"insertText":"GetSpectrum() \n\t\nend","label":{"name":"GetSpectrum","type":"(Function)"}},"GetConnectedWires":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AudioAnalyzer/GetConnectedWires)"]},"insertText":"GetConnectedWires(${1:pin}) \n\t\nend","label":{"name":"GetConnectedWires","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
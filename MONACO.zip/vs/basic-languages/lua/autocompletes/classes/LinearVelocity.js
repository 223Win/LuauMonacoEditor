define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"MaxAxesForce":{"label":{"name":"MaxAxesForce","type":"(Vector3)"}},"RelativeTo":{"label":{"name":"RelativeTo","type":"(ActuatorRelativeTo)"}},"MaxForce":{"label":{"name":"MaxForce","type":"(float)"}},"MaxPlanarAxesForce":{"label":{"name":"MaxPlanarAxesForce","type":"(Vector2)"}},"PrimaryTangentAxis":{"label":{"name":"PrimaryTangentAxis","type":"(Vector3)"}},"VectorVelocity":{"label":{"name":"VectorVelocity","type":"(Vector3)"}},"LineVelocity":{"label":{"name":"LineVelocity","type":"(float)"}},"ForceLimitMode":{"label":{"name":"ForceLimitMode","type":"(ForceLimitMode)"}},"LineDirection":{"label":{"name":"LineDirection","type":"(Vector3)"}},"VelocityConstraintMode":{"label":{"name":"VelocityConstraintMode","type":"(VelocityConstraintMode)"}},"SecondaryTangentAxis":{"label":{"name":"SecondaryTangentAxis","type":"(Vector3)"}},"ForceLimitsEnabled":{"label":{"name":"ForceLimitsEnabled","type":"(bool)"}},"PlaneVelocity":{"label":{"name":"PlaneVelocity","type":"(Vector2)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"GetMetadata":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/DataStoreSetOptions/GetMetadata)"]},"insertText":"GetMetadata() \n\t\nend","label":{"name":"GetMetadata","type":"(Function)"}},"SetMetadata":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/DataStoreSetOptions/SetMetadata)"]},"insertText":"SetMetadata(${1:attributes}) \n\t\nend","label":{"name":"SetMetadata","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
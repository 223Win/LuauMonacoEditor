define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"PassThrough":{"label":{"name":"PassThrough","type":"(bool)"}},"Label":{"label":{"name":"Label","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
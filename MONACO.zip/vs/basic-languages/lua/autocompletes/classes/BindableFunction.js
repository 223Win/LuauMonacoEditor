define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":{"OnInvoke":{"label":{"name":"OnInvoke","type":"(Callback)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/BindableFunction/OnInvoke)"]}}},"Method":{"Invoke":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/BindableFunction/Invoke)"]},"insertText":"Invoke(${1:arguments}) \n\t\nend","label":{"name":"Invoke","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"CreatePopupButton":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PluginToolbar/CreatePopupButton)"]},"insertText":"CreatePopupButton(${1:buttonId}, ${2:tooltip}, ${3:iconname}, ${4:text}) \n\t\nend","label":{"name":"CreatePopupButton","type":"(Function)"}},"CreateButton":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PluginToolbar/CreateButton)"]},"insertText":"CreateButton(${1:buttonId}, ${2:tooltip}, ${3:iconname}, ${4:text}) \n\t\nend","label":{"name":"CreateButton","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
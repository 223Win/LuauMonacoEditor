define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"GoodbyeChoiceActive":{"label":{"name":"GoodbyeChoiceActive","type":"(bool)"}},"UserDialog":{"label":{"name":"UserDialog","type":"(string)"}},"ResponseDialog":{"label":{"name":"ResponseDialog","type":"(string)"}},"GoodbyeDialog":{"label":{"name":"GoodbyeDialog","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
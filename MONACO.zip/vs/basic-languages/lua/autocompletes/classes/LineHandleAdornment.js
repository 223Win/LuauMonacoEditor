define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Thickness":{"label":{"name":"Thickness","type":"(float)"}},"Length":{"label":{"name":"Length","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"AudioInteractionGroup":{"label":{"name":"AudioInteractionGroup","type":"(string)"}}},"Event":[],"Method":{"GetConnectedWires":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AudioListener/GetConnectedWires)"]},"insertText":"GetConnectedWires(${1:pin}) \n\t\nend","label":{"name":"GetConnectedWires","type":"(Function)"}},"GetAudibilityOf":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AudioListener/GetAudibilityOf)"]},"insertText":"GetAudibilityOf(${1:emitter}) \n\t\nend","label":{"name":"GetAudibilityOf","type":"(Function)"}},"GetInteractingEmitters":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AudioListener/GetInteractingEmitters)"]},"insertText":"GetInteractingEmitters() \n\t\nend","label":{"name":"GetInteractingEmitters","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
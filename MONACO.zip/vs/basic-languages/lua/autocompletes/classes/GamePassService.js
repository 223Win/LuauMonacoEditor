define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"PlayerHasPass":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/GamePassService/PlayerHasPass)"]},"insertText":"PlayerHasPass(${1:player}, ${2:gamePassId}) \n\t\nend","label":{"name":"PlayerHasPass","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
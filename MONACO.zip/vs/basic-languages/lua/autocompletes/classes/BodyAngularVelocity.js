define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"P":{"label":{"name":"P","type":"(float)"}},"MaxTorque":{"label":{"name":"MaxTorque","type":"(Vector3)"}},"maxTorque":{"label":{"name":"maxTorque","type":"(Vector3)"}},"AngularVelocity":{"label":{"name":"AngularVelocity","type":"(Vector3)"}},"angularvelocity":{"label":{"name":"angularvelocity","type":"(Vector3)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
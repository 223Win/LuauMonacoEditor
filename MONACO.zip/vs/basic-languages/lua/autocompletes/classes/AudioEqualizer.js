define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"MidRange":{"label":{"name":"MidRange","type":"(NumberRange)"}},"MidGain":{"label":{"name":"MidGain","type":"(float)"}},"LowGain":{"label":{"name":"LowGain","type":"(float)"}},"HighGain":{"label":{"name":"HighGain","type":"(float)"}}},"Event":[],"Method":{"GetConnectedWires":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AudioEqualizer/GetConnectedWires)"]},"insertText":"GetConnectedWires(${1:pin}) \n\t\nend","label":{"name":"GetConnectedWires","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
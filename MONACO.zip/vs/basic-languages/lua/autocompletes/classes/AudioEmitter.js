define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"AudioInteractionGroup":{"label":{"name":"AudioInteractionGroup","type":"(string)"}}},"Event":[],"Method":{"GetConnectedWires":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AudioEmitter/GetConnectedWires)"]},"insertText":"GetConnectedWires(${1:pin}) \n\t\nend","label":{"name":"GetConnectedWires","type":"(Function)"}},"GetInteractingListeners":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AudioEmitter/GetInteractingListeners)"]},"insertText":"GetInteractingListeners() \n\t\nend","label":{"name":"GetInteractingListeners","type":"(Function)"}},"GetAudibilityFor":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AudioEmitter/GetAudibilityFor)"]},"insertText":"GetAudibilityFor(${1:listener}) \n\t\nend","label":{"name":"GetAudibilityFor","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
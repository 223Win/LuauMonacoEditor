define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Visible":{"label":{"name":"Visible","type":"(bool)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
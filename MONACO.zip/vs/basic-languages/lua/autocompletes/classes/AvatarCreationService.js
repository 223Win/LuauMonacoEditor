define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"PromptCreateAvatarAsync":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AvatarCreationService/PromptCreateAvatarAsync)"]},"insertText":"PromptCreateAvatarAsync(${1:player}, ${2:humanoidDescription}) \n\t\nend","label":{"name":"PromptCreateAvatarAsync","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Pitch":{"label":{"name":"Pitch","type":"(float)"}}},"Event":[],"Method":{"GetConnectedWires":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/AudioPitchShifter/GetConnectedWires)"]},"insertText":"GetConnectedWires(${1:pin}) \n\t\nend","label":{"name":"GetConnectedWires","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
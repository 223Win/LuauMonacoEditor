define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"IsUserDataAvailable":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PlatformCloudStorageService/IsUserDataAvailable)"]},"insertText":"IsUserDataAvailable() \n\t\nend","label":{"name":"IsUserDataAvailable","type":"(Function)"}},"SetUserDataAsync":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PlatformCloudStorageService/SetUserDataAsync)"]},"insertText":"SetUserDataAsync(${1:key}, ${2:data}) \n\t\nend","label":{"name":"SetUserDataAsync","type":"(Function)"}},"GetUserDataAsync":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/PlatformCloudStorageService/GetUserDataAsync)"]},"insertText":"GetUserDataAsync(${1:key}) \n\t\nend","label":{"name":"GetUserDataAsync","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
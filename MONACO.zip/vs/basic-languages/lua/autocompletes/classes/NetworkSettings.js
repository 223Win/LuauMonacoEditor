define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"FreeMemoryMBytes":{"label":{"name":"FreeMemoryMBytes","type":"(float)"}},"PrintStreamInstanceQuota":{"label":{"name":"PrintStreamInstanceQuota","type":"(bool)"}},"EmulatedTotalMemoryInMB":{"label":{"name":"EmulatedTotalMemoryInMB","type":"(int)"}},"RenderStreamedRegions":{"label":{"name":"RenderStreamedRegions","type":"(bool)"}},"PrintPhysicsErrors":{"label":{"name":"PrintPhysicsErrors","type":"(bool)"}},"HttpProxyURL":{"label":{"name":"HttpProxyURL","type":"(string)"}},"HttpProxyEnabled":{"label":{"name":"HttpProxyEnabled","type":"(bool)"}},"IncomingReplicationLag":{"label":{"name":"IncomingReplicationLag","type":"(double)"}},"PrintJoinSizeBreakdown":{"label":{"name":"PrintJoinSizeBreakdown","type":"(bool)"}},"ShowActiveAnimationAsset":{"label":{"name":"ShowActiveAnimationAsset","type":"(bool)"}},"RandomizeJoinInstanceOrder":{"label":{"name":"RandomizeJoinInstanceOrder","type":"(bool)"}},"OpenCertManagerDialog":{"label":{"name":"OpenCertManagerDialog","type":"(int)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
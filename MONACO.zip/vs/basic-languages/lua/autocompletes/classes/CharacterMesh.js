define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"OverlayTextureId":{"label":{"name":"OverlayTextureId","type":"(int64)"}},"MeshId":{"label":{"name":"MeshId","type":"(int64)"}},"BaseTextureId":{"label":{"name":"BaseTextureId","type":"(int64)"}},"BodyPart":{"label":{"name":"BodyPart","type":"(BodyPart)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
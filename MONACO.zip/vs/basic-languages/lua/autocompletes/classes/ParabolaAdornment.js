define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"A":{"label":{"name":"A","type":"(float)"}},"C":{"label":{"name":"C","type":"(float)"}},"B":{"label":{"name":"B","type":"(float)"}},"Range":{"label":{"name":"Range","type":"(float)"}},"Thickness":{"label":{"name":"Thickness","type":"(float)"}}},"Event":[],"Method":{"FindPartOnParabola":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ParabolaAdornment/FindPartOnParabola)"]},"insertText":"FindPartOnParabola(${1:ignoreDescendentsTable}) \n\t\nend","label":{"name":"FindPartOnParabola","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
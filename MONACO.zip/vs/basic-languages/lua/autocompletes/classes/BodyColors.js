define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"LeftArmColor3":{"label":{"name":"LeftArmColor3","type":"(Color3)"}},"RightLegColor":{"label":{"name":"RightLegColor","type":"(BrickColor)"}},"LeftLegColor":{"label":{"name":"LeftLegColor","type":"(BrickColor)"}},"HeadColor3":{"label":{"name":"HeadColor3","type":"(Color3)"}},"LeftLegColor3":{"label":{"name":"LeftLegColor3","type":"(Color3)"}},"TorsoColor":{"label":{"name":"TorsoColor","type":"(BrickColor)"}},"LeftArmColor":{"label":{"name":"LeftArmColor","type":"(BrickColor)"}},"TorsoColor3":{"label":{"name":"TorsoColor3","type":"(Color3)"}},"RightLegColor3":{"label":{"name":"RightLegColor3","type":"(Color3)"}},"RightArmColor":{"label":{"name":"RightArmColor","type":"(BrickColor)"}},"HeadColor":{"label":{"name":"HeadColor","type":"(BrickColor)"}},"RightArmColor3":{"label":{"name":"RightArmColor3","type":"(Color3)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
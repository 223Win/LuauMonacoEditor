define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"AttachmentRight":{"label":{"name":"AttachmentRight","type":"(Vector3)"}},"AttachmentPos":{"label":{"name":"AttachmentPos","type":"(Vector3)"}},"AttachmentPoint":{"label":{"name":"AttachmentPoint","type":"(CFrame)"}},"BackendAccoutrementState":{"label":{"name":"BackendAccoutrementState","type":"(int)"}},"AttachmentUp":{"label":{"name":"AttachmentUp","type":"(Vector3)"}},"AttachmentForward":{"label":{"name":"AttachmentForward","type":"(Vector3)"}}},"Event":{"ServerEquipAccoutrement":{"label":{"name":"ServerEquipAccoutrement","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Accoutrement/ServerEquipAccoutrement)"]}},"ServerUnequipAccoutrement":{"label":{"name":"ServerUnequipAccoutrement","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Accoutrement/ServerUnequipAccoutrement)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
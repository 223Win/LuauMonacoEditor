define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"MaxItems":{"label":{"name":"MaxItems","type":"(int)"}}},"Event":[],"Method":{"SetLegacyMaxItems":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Debris/SetLegacyMaxItems)"]},"insertText":"SetLegacyMaxItems(${1:enabled}) \n\t\nend","label":{"name":"SetLegacyMaxItems","type":"(Function)"}},"addItem":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Debris/addItem)"]},"insertText":"addItem(${1:item}, ${2:lifetime}) \n\t\nend","label":{"name":"addItem","type":"(Function)"}},"AddItem":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Debris/AddItem)"]},"insertText":"AddItem(${1:item}, ${2:lifetime}) \n\t\nend","label":{"name":"AddItem","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
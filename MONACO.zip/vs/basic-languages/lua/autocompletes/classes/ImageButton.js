define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"ImageColor3":{"label":{"name":"ImageColor3","type":"(Color3)"}},"HoverImage":{"label":{"name":"HoverImage","type":"(Content)"}},"ImageTransparency":{"label":{"name":"ImageTransparency","type":"(float)"}},"IsLoaded":{"label":{"name":"IsLoaded","type":"(bool)"}},"ImageRectSize":{"label":{"name":"ImageRectSize","type":"(Vector2)"}},"PressedImage":{"label":{"name":"PressedImage","type":"(Content)"}},"ScaleType":{"label":{"name":"ScaleType","type":"(ScaleType)"}},"ImageRectOffset":{"label":{"name":"ImageRectOffset","type":"(Vector2)"}},"TileSize":{"label":{"name":"TileSize","type":"(UDim2)"}},"ContentImageSize":{"label":{"name":"ContentImageSize","type":"(Vector2)"}},"SliceScale":{"label":{"name":"SliceScale","type":"(float)"}},"ResampleMode":{"label":{"name":"ResampleMode","type":"(ResamplerMode)"}},"Image":{"label":{"name":"Image","type":"(Content)"}},"SliceCenter":{"label":{"name":"SliceCenter","type":"(Rect)"}}},"Event":[],"Method":{"SetEnableContentImageSizeChangedEvents":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/ImageButton/SetEnableContentImageSizeChangedEvents)"]},"insertText":"SetEnableContentImageSizeChangedEvents(${1:enabled}) \n\t\nend","label":{"name":"SetEnableContentImageSizeChangedEvents","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
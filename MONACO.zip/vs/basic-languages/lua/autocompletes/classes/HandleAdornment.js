define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"AdornCullingMode":{"label":{"name":"AdornCullingMode","type":"(AdornCullingMode)"}},"ZIndex":{"label":{"name":"ZIndex","type":"(int)"}},"CFrame":{"label":{"name":"CFrame","type":"(CFrame)"}},"AlwaysOnTop":{"label":{"name":"AlwaysOnTop","type":"(bool)"}},"SizeRelativeOffset":{"label":{"name":"SizeRelativeOffset","type":"(Vector3)"}}},"Event":{"MouseEnter":{"label":{"name":"MouseEnter","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/HandleAdornment/MouseEnter)"]}},"MouseButton1Down":{"label":{"name":"MouseButton1Down","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/HandleAdornment/MouseButton1Down)"]}},"MouseButton1Up":{"label":{"name":"MouseButton1Up","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/HandleAdornment/MouseButton1Up)"]}},"MouseLeave":{"label":{"name":"MouseLeave","type":"(RBXScriptSignal)"},"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/HandleAdornment/MouseLeave)"]}}},"Method":[],

__requires__: [['classes/Instance']],}})
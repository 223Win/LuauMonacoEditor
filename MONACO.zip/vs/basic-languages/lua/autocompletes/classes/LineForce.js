define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"Magnitude":{"label":{"name":"Magnitude","type":"(float)"}},"ApplyAtCenterOfMass":{"label":{"name":"ApplyAtCenterOfMass","type":"(bool)"}},"MaxForce":{"label":{"name":"MaxForce","type":"(float)"}},"ReactionForceEnabled":{"label":{"name":"ReactionForceEnabled","type":"(bool)"}},"InverseSquareLaw":{"label":{"name":"InverseSquareLaw","type":"(bool)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
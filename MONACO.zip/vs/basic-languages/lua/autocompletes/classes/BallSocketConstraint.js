define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"LimitsEnabled":{"label":{"name":"LimitsEnabled","type":"(bool)"}},"Radius":{"label":{"name":"Radius","type":"(float)"}},"TwistLowerAngle":{"label":{"name":"TwistLowerAngle","type":"(float)"}},"UpperAngle":{"label":{"name":"UpperAngle","type":"(float)"}},"MaxFrictionTorqueXml":{"label":{"name":"MaxFrictionTorqueXml","type":"(float)"}},"Restitution":{"label":{"name":"Restitution","type":"(float)"}},"TwistLimitsEnabled":{"label":{"name":"TwistLimitsEnabled","type":"(bool)"}},"TwistUpperAngle":{"label":{"name":"TwistUpperAngle","type":"(float)"}},"MaxFrictionTorque":{"label":{"name":"MaxFrictionTorque","type":"(float)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
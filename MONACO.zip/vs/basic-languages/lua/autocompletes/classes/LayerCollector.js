define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"ResetOnSpawn":{"label":{"name":"ResetOnSpawn","type":"(bool)"}},"Enabled":{"label":{"name":"Enabled","type":"(bool)"}},"ZIndexBehavior":{"label":{"name":"ZIndexBehavior","type":"(ZIndexBehavior)"}}},"Event":[],"Method":{"GetLayoutNodeTree":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/LayerCollector/GetLayoutNodeTree)"]},"insertText":"GetLayoutNodeTree() \n\t\nend","label":{"name":"GetLayoutNodeTree","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
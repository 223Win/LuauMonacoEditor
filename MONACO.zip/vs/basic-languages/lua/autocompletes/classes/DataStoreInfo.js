define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"CreatedTime":{"label":{"name":"CreatedTime","type":"(int64)"}},"UpdatedTime":{"label":{"name":"UpdatedTime","type":"(int64)"}},"DataStoreName":{"label":{"name":"DataStoreName","type":"(string)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})
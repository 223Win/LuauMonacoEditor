define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"SetOutgoingKBPSLimit":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/NetworkPeer/SetOutgoingKBPSLimit)"]},"insertText":"SetOutgoingKBPSLimit(${1:limit}) \n\t\nend","label":{"name":"SetOutgoingKBPSLimit","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
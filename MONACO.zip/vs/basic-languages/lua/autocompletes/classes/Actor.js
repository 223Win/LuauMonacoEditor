define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":[],"Event":[],"Method":{"SendMessage":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Actor/SendMessage)"]},"insertText":"SendMessage(${1:topic}, ${2:message}) \n\t\nend","label":{"name":"SendMessage","type":"(Function)"}},"BindToMessageParallel":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Actor/BindToMessageParallel)"]},"insertText":"BindToMessageParallel(${1:topic}, ${2:function}) \n\t\nend","label":{"name":"BindToMessageParallel","type":"(Function)"}},"BindToMessage":{"documentation":{"value":["[View documentation](https://developer.roblox.com/en-us/api-reference/events/Actor/BindToMessage)"]},"insertText":"BindToMessage(${1:topic}, ${2:function}) \n\t\nend","label":{"name":"BindToMessage","type":"(Function)"}}},

__requires__: [['classes/Instance']],}})
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });

    exports.autocompletes = {



    

"Field":{"RestPose":{"label":{"name":"RestPose","type":"(RestPose)"}},"ScaleUnit":{"label":{"name":"ScaleUnit","type":"(MeshScaleUnit)"}},"RigScale":{"label":{"name":"RigScale","type":"(RigScale)"}},"Anchored":{"label":{"name":"Anchored","type":"(bool)"}},"ImportAsModelAsset":{"label":{"name":"ImportAsModelAsset","type":"(bool)"}},"InsertInWorkspace":{"label":{"name":"InsertInWorkspace","type":"(bool)"}},"UseSceneOriginAsCFrame":{"label":{"name":"UseSceneOriginAsCFrame","type":"(bool)"}},"RigVisualization":{"label":{"name":"RigVisualization","type":"(bool)"}},"WorldForward":{"label":{"name":"WorldForward","type":"(NormalId)"}},"UsesCages":{"label":{"name":"UsesCages","type":"(bool)"}},"RigType":{"label":{"name":"RigType","type":"(RigType)"}},"ExistingPackageId":{"label":{"name":"ExistingPackageId","type":"(string)"}},"MergeMeshes":{"label":{"name":"MergeMeshes","type":"(bool)"}},"UseSceneOriginAsPivot":{"label":{"name":"UseSceneOriginAsPivot","type":"(bool)"}},"PolygonCount":{"label":{"name":"PolygonCount","type":"(float)"}},"AddModelToInventory":{"label":{"name":"AddModelToInventory","type":"(bool)"}},"ImportAsPackage":{"label":{"name":"ImportAsPackage","type":"(bool)"}},"AnimationIdForRestPose":{"label":{"name":"AnimationIdForRestPose","type":"(float)"}},"InsertWithScenePosition":{"label":{"name":"InsertWithScenePosition","type":"(bool)"}},"WorldUp":{"label":{"name":"WorldUp","type":"(NormalId)"}},"ValidateUgcBody":{"label":{"name":"ValidateUgcBody","type":"(bool)"}},"FileDimensions":{"label":{"name":"FileDimensions","type":"(Vector3)"}},"InvertNegativeFaces":{"label":{"name":"InvertNegativeFaces","type":"(bool)"}}},"Event":[],"Method":[],

__requires__: [['classes/Instance']],}})